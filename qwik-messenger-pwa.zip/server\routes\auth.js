const express = require('express');
const router = express.Router();
const { registerUser, loginUser, getCurrentUser } = require('../controllers/authController');
const { authenticateToken } = require('../middleware/auth');

// Регистрация нового пользователя
router.post('/register', registerUser);

// Вход пользователя
router.post('/login', loginUser);

// Получение данных текущего пользователя
router.get('/me', authenticateToken, getCurrentUser);

module.exports = router; 