const fs = require('fs');
const path = require('path');

// Цвета для иконки
const COLORS = {
  BACKGROUND: '#4a6ee0',
  FOREGROUND: '#ffffff'
};

// Функция для создания базовой иконки в формате SVG
function createBasicIcon() {
  // Путь для сохранения иконки
  const outputPath = path.join(__dirname, 'basic-qwik-icon.svg');
  
  // Создаем простой SVG
  const svgContent = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <!-- Фон -->
  <circle cx="256" cy="256" r="256" fill="${COLORS.BACKGROUND}"/>
  
  <!-- Буква Q -->
  <path fill="${COLORS.FOREGROUND}" d="M256 120c-66 0-120 54-120 120 0 66 54 120 120 120 12.5 0 24.5-2 36-5.5 18 18 40.5 28.5 64 35-10-16-17-35-20-55 25-22.5 40-55 40-90 0-70-54-124.5-120-124.5z"/>
  
  <!-- Хвостик Q -->
  <path fill="${COLORS.FOREGROUND}" d="M310 320l40 40c-10 10-22 18-35 24l-20-50c5-4 10-9 15-14z"/>
</svg>`;
  
  // Записываем файл
  fs.writeFileSync(outputPath, svgContent);
  console.log(`✅ Создана базовая SVG иконка: ${outputPath}`);
  
  // Создаем HTML файл, который можно открыть в браузере для просмотра и сохранения иконки
  const htmlPath = path.join(__dirname, 'view-icon.html');
  const htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Просмотр иконки Qwik</title>
  <style>
    body { font-family: Arial, sans-serif; text-align: center; margin: 20px; }
    .icon-preview { margin: 20px auto; max-width: 512px; border: 1px solid #ddd; padding: 10px; }
    .sizes { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin: 20px 0; }
    .size-preview { border: 1px solid #eee; padding: 10px; }
    button { background: ${COLORS.BACKGROUND}; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; margin: 5px; }
  </style>
</head>
<body>
  <h1>Просмотр иконки Qwik Мессенджера</h1>
  <div class="icon-preview">
    <img src="basic-qwik-icon.svg" alt="Qwik Icon" width="256" height="256">
  </div>
  <div class="sizes">
    <div class="size-preview">
      <img src="basic-qwik-icon.svg" alt="16x16" width="16" height="16">
      <p>16x16</p>
    </div>
    <div class="size-preview">
      <img src="basic-qwik-icon.svg" alt="32x32" width="32" height="32">
      <p>32x32</p>
    </div>
    <div class="size-preview">
      <img src="basic-qwik-icon.svg" alt="64x64" width="64" height="64">
      <p>64x64</p>
    </div>
    <div class="size-preview">
      <img src="basic-qwik-icon.svg" alt="128x128" width="128" height="128">
      <p>128x128</p>
    </div>
  </div>
  <p>Для использования этой иконки в качестве favicon, сохраните её как PNG и переименуйте в favicon.ico</p>
  <p>Вы можете щелкнуть правой кнопкой мыши по изображению и выбрать "Сохранить изображение как..."</p>
</body>
</html>`;
  
  fs.writeFileSync(htmlPath, htmlContent);
  console.log(`✅ Создан HTML файл для просмотра иконки: ${htmlPath}`);
}

// Запускаем создание иконки
console.log('🚀 Создаю простую иконку для Qwik Мессенджера...');
createBasicIcon();
console.log('✨ Готово! Откройте view-icon.html в браузере для просмотра иконки.'); 