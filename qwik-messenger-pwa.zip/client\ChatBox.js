import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import { FaPaperPlane, FaSmile, FaPaperclip } from 'react-icons/fa';
import { format } from 'timeago.js';
import { useAuth } from '../contexts/AuthContext';
import { getMessages, sendMessage } from '../api/messageApi';

const ChatBoxContainer = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100%;
`;

const ChatHeader = styled.div`
  padding: 16px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #ddd;
  background-color: #f0f2f5;
`;

const ContactAvatar = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 12px;
`;

const ContactInfo = styled.div`
  flex: 1;
`;

const ContactName = styled.div`
  font-weight: 500;
  font-size: 16px;
`;

const ContactStatus = styled.div`
  font-size: 13px;
  color: ${({ online }) => (online ? '#4caf50' : '#666')};
`;

const MessagesContainer = styled.div`
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  background-color: #e5ddd5;
  display: flex;
  flex-direction: column;
`;

const MessageGroup = styled.div`
  display: flex;
  flex-direction: column;
  align-items: ${({ isMine }) => (isMine ? 'flex-end' : 'flex-start')};
  margin-bottom: 16px;
`;

const Message = styled.div`
  max-width: 60%;
  padding: 8px 12px;
  border-radius: 8px;
  background-color: ${({ isMine }) => (isMine ? '#dcf8c6' : 'white')};
  margin-bottom: 4px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  word-wrap: break-word;
`;

const MessageText = styled.div`
  font-size: 14px;
`;

const MessageTime = styled.div`
  font-size: 11px;
  color: #999;
  text-align: right;
  margin-top: 2px;
`;

const InputContainer = styled.div`
  padding: 10px 16px;
  display: flex;
  align-items: center;
  background-color: #f0f2f5;
`;

const IconButton = styled.button`
  background: none;
  border: none;
  color: #666;
  font-size: 20px;
  cursor: pointer;
  margin: 0 8px;
  
  &:hover {
    color: #4a6ee0;
  }
`;

const MessageInput = styled.input`
  flex: 1;
  padding: 10px 16px;
  border-radius: 20px;
  border: none;
  background-color: white;
  font-size: 14px;
  
  &:focus {
    outline: none;
  }
`;

const EmptyChatContainer = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #f5f5f5;
  color: #666;
`;

const EmptyChatText = styled.div`
  font-size: 18px;
  margin-top: 16px;
`;

function ChatBox({ selectedContact }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { currentUser } = useAuth();
  const messagesEndRef = useRef(null);
  
  // Загрузка сообщений при выборе контакта
  useEffect(() => {
    if (selectedContact) {
      const fetchMessages = async () => {
        try {
          setLoading(true);
          const data = await getMessages(selectedContact._id);
          setMessages(data);
          setLoading(false);
        } catch (error) {
          console.error('Ошибка при загрузке сообщений:', error);
          setLoading(false);
        }
      };
      
      fetchMessages();
    }
  }, [selectedContact]);
  
  // Прокрутка к последнему сообщению
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Отправка сообщения
  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;
    
    try {
      const sentMessage = await sendMessage(selectedContact._id, newMessage);
      setMessages([...messages, sentMessage]);
      setNewMessage('');
    } catch (error) {
      console.error('Ошибка при отправке сообщения:', error);
    }
  };
  
  // Группировка сообщений по отправителю
  const groupMessagesBySender = () => {
    const groups = [];
    let currentGroup = null;
    
    messages.forEach(message => {
      const isMine = message.sender._id === currentUser._id;
      
      if (!currentGroup || currentGroup.isMine !== isMine) {
        currentGroup = {
          isMine,
          messages: [message]
        };
        groups.push(currentGroup);
      } else {
        currentGroup.messages.push(message);
      }
    });
    
    return groups;
  };
  
  if (!selectedContact) {
    return (
      <EmptyChatContainer>
        <EmptyChatText>Выберите контакт для начала общения</EmptyChatText>
      </EmptyChatContainer>
    );
  }
  
  return (
    <ChatBoxContainer>
      <ChatHeader>
        <ContactAvatar src={selectedContact.avatar} alt={selectedContact.username} />
        <ContactInfo>
          <ContactName>{selectedContact.username}</ContactName>
          <ContactStatus online={selectedContact.status === 'online'}>
            {selectedContact.status === 'online' ? 'В сети' : 'Не в сети'}
          </ContactStatus>
        </ContactInfo>
      </ChatHeader>
      
      <MessagesContainer>
        {loading ? (
          <div>Загрузка сообщений...</div>
        ) : (
          groupMessagesBySender().map((group, groupIndex) => (
            <MessageGroup key={groupIndex} isMine={group.isMine}>
              {group.messages.map((message, messageIndex) => (
                <Message key={message._id || messageIndex} isMine={group.isMine}>
                  <MessageText>{message.content}</MessageText>
                  <MessageTime>{format(message.createdAt)}</MessageTime>
                </Message>
              ))}
            </MessageGroup>
          ))
        )}
        <div ref={messagesEndRef} />
      </MessagesContainer>
      
      <InputContainer>
        <IconButton>
          <FaSmile />
        </IconButton>
        <IconButton>
          <FaPaperclip />
        </IconButton>
        <MessageInput
          type="text"
          placeholder="Введите сообщение..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(e)}
        />
        <IconButton onClick={handleSendMessage}>
          <FaPaperPlane />
        </IconButton>
      </InputContainer>
    </ChatBoxContainer>
  );
}

export default ChatBox; 