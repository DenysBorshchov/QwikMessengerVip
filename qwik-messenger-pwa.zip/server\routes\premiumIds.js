const express = require('express');
const router = express.Router();
const { 
  getAvailableIds, 
  getUserRentedIds, 
  rentPremiumId,
  extendRental,
  setCustomIdText
} = require('../controllers/premiumIdController');
const { authenticateToken } = require('../middleware/auth');

// Получение списка доступных премиальных ID (публичный доступ)
router.get('/available', getAvailableIds);

// Получение списка арендованных пользователем ID (требуется аутентификация)
router.get('/user/:userId', authenticateToken, getUserRentedIds);

// Аренда премиального ID (требуется аутентификация)
router.post('/rent', authenticateToken, rentPremiumId);

// Продление аренды ID (требуется аутентификация)
router.post('/extend', authenticateToken, extendRental);

// Установка произвольного текста для ID (требуется аутентификация)
router.post('/customize', authenticateToken, setCustomIdText);

module.exports = router; 