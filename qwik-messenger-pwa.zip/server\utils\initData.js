const PremiumId = require('../models/PremiumId');

// Инициализация 100 премиальных ID в базе данных
exports.initializePremiumIds = async () => {
  try {
    // Проверяем, есть ли уже ID в базе
    const count = await PremiumId.countDocuments();
    if (count > 0) {
      console.log(`В базе уже есть ${count} премиальных ID`);
      return;
    }
    
    console.log('Инициализация премиальных ID...');
    
    // Создаем массив для 100 премиальных ID
    const premiumIds = [];
    
    // Генерируем ID с разными ценами в зависимости от "красоты" номера
    for (let i = 1; i <= 100; i++) {
      let price = 10; // Базовая цена за месяц
      let idValue = '';
      
      // Определяем формат и цену ID
      if (i <= 10) {
        // Топ-10 ID (premium_001 - premium_010)
        idValue = `premium_${i.toString().padStart(3, '0')}`;
        price = 50; // Дороже обычных
      } else if (i <= 50) {
        // ID 11-50 (special_011 - special_050)
        idValue = `special_${i.toString().padStart(3, '0')}`;
        price = 25; // Средняя цена
      } else {
        // Обычные ID (standard_051 - standard_100)
        idValue = `standard_${i.toString().padStart(3, '0')}`;
        price = 10; // Базовая цена
      }
      
      // Добавляем специальные "красивые" ID
      if (i === 1) {
        idValue = 'vip_gold'; // Самый дорогой ID
        price = 100;
      } else if (i === 2) {
        idValue = 'vip_silver';
        price = 80;
      } else if (i === 3) {
        idValue = 'vip_bronze';
        price = 60;
      }
      
      // Добавляем ID в массив
      premiumIds.push({
        idValue,
        price,
        status: 'available'
      });
    }
    
    // Добавляем несколько специальных ID с возможностью произвольного текста
    premiumIds.push({
      idValue: 'custom_text_1',
      price: 150,
      status: 'available'
    });
    
    premiumIds.push({
      idValue: 'custom_text_2',
      price: 150,
      status: 'available'
    });
    
    premiumIds.push({
      idValue: 'custom_text_3',
      price: 150,
      status: 'available'
    });
    
    // Сохраняем все ID в базу
    await PremiumId.insertMany(premiumIds);
    
    console.log(`Успешно создано ${premiumIds.length} премиальных ID`);
  } catch (error) {
    console.error('Ошибка инициализации премиальных ID:', error.message);
  }
}; 