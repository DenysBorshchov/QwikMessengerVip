const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { registerUser, loginUser } = require('../controllers/authController');

// Мок для запроса и ответа
const mockRequest = (body = {}) => ({ body });
const mockResponse = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  res.send = jest.fn().mockReturnValue(res);
  return res;
};

// Мок для mongoose и bcrypt
jest.mock('mongoose');
jest.mock('bcryptjs');
jest.mock('jsonwebtoken');

// Мок для модели User
jest.mock('../models/User', () => {
  return {
    findOne: jest.fn(),
    prototype: {
      save: jest.fn()
    }
  };
});

describe('Тесты контроллера аутентификации', () => {
  beforeEach(() => {
    process.env.JWT_SECRET = 'test_secret';
    jest.clearAllMocks();
  });

  describe('registerUser', () => {
    it('должен зарегистрировать нового пользователя', async () => {
      // Настройка моков
      User.findOne
        .mockResolvedValueOnce(null) // email не существует
        .mockResolvedValueOnce(null); // username не существует
      
      bcrypt.genSalt.mockResolvedValue('salt');
      bcrypt.hash.mockResolvedValue('hashedPassword');
      
      const userMock = new User();
      userMock.save = jest.fn().mockResolvedValue({
        id: 'user_id',
        username: 'testuser',
        email: 'test@example.com'
      });
      
      jest.spyOn(User.prototype, 'save').mockImplementation(userMock.save);
      
      jwt.sign.mockImplementation((payload, secret, options, callback) => {
        callback(null, 'test_token');
      });

      // Вызов функции
      const req = mockRequest({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });
      const res = mockResponse();

      await registerUser(req, res);

      // Проверки
      expect(User.findOne).toHaveBeenCalledTimes(2);
      expect(bcrypt.genSalt).toHaveBeenCalledWith(10);
      expect(bcrypt.hash).toHaveBeenCalledWith('password123', 'salt');
      expect(jwt.sign).toHaveBeenCalled();
      expect(res.json).toHaveBeenCalledWith({
        token: 'test_token',
        user: expect.objectContaining({
          username: 'testuser',
          email: 'test@example.com'
        })
      });
    });

    it('должен вернуть ошибку, если пользователь с таким email уже существует', async () => {
      // Настройка моков
      User.findOne.mockResolvedValueOnce({
        email: 'test@example.com'
      });

      // Вызов функции
      const req = mockRequest({
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      });
      const res = mockResponse();

      await registerUser(req, res);

      // Проверки
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: 'Пользователь с таким email уже существует'
      });
    });
  });

  describe('loginUser', () => {
    it('должен войти пользователя с правильными учетными данными', async () => {
      // Настройка моков
      User.findOne.mockResolvedValue({
        id: 'user_id',
        email: 'test@example.com',
        username: 'testuser',
        password: 'hashedPassword'
      });
      
      bcrypt.compare.mockResolvedValue(true);
      
      jwt.sign.mockImplementation((payload, secret, options, callback) => {
        callback(null, 'test_token');
      });

      // Вызов функции
      const req = mockRequest({
        email: 'test@example.com',
        password: 'password123'
      });
      const res = mockResponse();

      await loginUser(req, res);

      // Проверки
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(bcrypt.compare).toHaveBeenCalledWith('password123', 'hashedPassword');
      expect(jwt.sign).toHaveBeenCalled();
      expect(res.json).toHaveBeenCalledWith({
        token: 'test_token',
        user: expect.objectContaining({
          username: 'testuser',
          email: 'test@example.com'
        })
      });
    });

    it('должен вернуть ошибку при неверных учетных данных', async () => {
      // Настройка моков
      User.findOne.mockResolvedValue({
        email: 'test@example.com',
        password: 'hashedPassword'
      });
      
      bcrypt.compare.mockResolvedValue(false);

      // Вызов функции
      const req = mockRequest({
        email: 'test@example.com',
        password: 'wrongpassword'
      });
      const res = mockResponse();

      await loginUser(req, res);

      // Проверки
      expect(User.findOne).toHaveBeenCalledWith({ email: 'test@example.com' });
      expect(bcrypt.compare).toHaveBeenCalledWith('wrongpassword', 'hashedPassword');
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: 'Неверные учетные данные'
      });
    });
  });
}); 