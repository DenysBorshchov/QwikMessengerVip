import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { AuthContext } from '../contexts/AuthContext';

// Стили для панели навигации
const NavBarContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  background-color: #4a6ee0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 15px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  z-index: 100;
`;

// Логотип
const Logo = styled.div`
  color: white;
  font-weight: bold;
  font-size: 20px;
  display: flex;
  align-items: center;
  
  svg {
    margin-right: 8px;
  }
`;

// Кнопка меню
const MenuButton = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: white;
`;

// Мобильное меню
const MobileMenu = styled.div`
  position: fixed;
  top: 60px;
  left: 0;
  right: 0;
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  z-index: 99;
  transform: ${props => props.isOpen ? 'translateY(0)' : 'translateY(-100%)'};
  transition: transform 0.3s ease;
`;

// Пункт меню
const MenuItem = styled(Link)`
  display: block;
  padding: 15px;
  border-bottom: 1px solid #eee;
  color: #333;
  text-decoration: none;
  
  &:hover, &:active {
    background-color: #f5f5f5;
  }
`;

// Отображение кредитов пользователя
const Credits = styled.div`
  color: white;
  display: flex;
  align-items: center;
  font-size: 14px;
  margin-right: 10px;
  
  svg {
    margin-right: 5px;
  }
`;

// Иконка меню
const MenuIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 18H21V16H3V18ZM3 13H21V11H3V13ZM3 6V8H21V6H3Z" fill="white" />
  </svg>
);

// Иконка логотипа Q
const LogoIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20Z" fill="white" />
    <path d="M13 7H10V13H13C14.65 13 16 11.65 16 10C16 8.35 14.65 7 13 7Z" fill="white" />
    <path d="M13 15H9V17H13C14.1 17 15 16.1 15 15C15 15 15 15 13 15Z" fill="white" />
  </svg>
);

// Иконка монеты (кредитов)
const CoinIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20Z" fill="white" />
    <path d="M12.5 7H11V12.25L15.75 15.25L16.5 14L12.5 11.25V7Z" fill="white" />
  </svg>
);

const MobileNavBar = () => {
  const { user, logout } = useContext(AuthContext);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  // Обработчик выхода из аккаунта
  const handleLogout = () => {
    logout();
    setMenuOpen(false);
    navigate('/login');
  };
  
  // Переключение меню
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };
  
  // Закрытие меню
  const closeMenu = () => {
    setMenuOpen(false);
  };
  
  return (
    <>
      <NavBarContainer>
        <Logo>
          <LogoIcon />
          Qwik
        </Logo>
        
        {user && (
          <Credits>
            <CoinIcon />
            {user.credits || 0}
          </Credits>
        )}
        
        <MenuButton onClick={toggleMenu}>
          <MenuIcon />
        </MenuButton>
      </NavBarContainer>
      
      {user && (
        <MobileMenu isOpen={menuOpen}>
          <MenuItem to="/" onClick={closeMenu}>Чат</MenuItem>
          <MenuItem to="/premium-ids" onClick={closeMenu}>Премиум ID</MenuItem>
          <MenuItem to="/credits" onClick={closeMenu}>Купить кредиты</MenuItem>
          <MenuItem as="div" onClick={handleLogout} style={{ cursor: 'pointer' }}>Выйти</MenuItem>
        </MobileMenu>
      )}
    </>
  );
};

export default MobileNavBar; 