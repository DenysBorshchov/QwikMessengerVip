const PremiumId = require('../models/PremiumId');
const User = require('../models/User');

// Получение списка доступных премиальных ID
exports.getAvailableIds = async (req, res) => {
  try {
    // Находим все доступные ID и сортируем по цене
    const availableIds = await PremiumId.find({ status: 'available' })
      .sort({ price: 1 });
    
    res.json(availableIds);
  } catch (error) {
    console.error('Ошибка получения премиальных ID:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Получение арендованных пользователем ID
exports.getUserRentedIds = async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Находим ID, арендованные пользователем
    const rentedIds = await PremiumId.find({ 
      currentOwner: userId,
      status: 'rented'
    });
    
    res.json(rentedIds);
  } catch (error) {
    console.error('Ошибка получения арендованных ID:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Аренда премиального ID
exports.rentPremiumId = async (req, res) => {
  try {
    const { idValue, months = 1 } = req.body;
    const userId = req.user.id;
    
    // Находим пользователя
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Находим премиальный ID
    const premiumId = await PremiumId.findOne({ idValue });
    if (!premiumId) {
      return res.status(404).json({ message: 'Премиальный ID не найден' });
    }
    
    // Проверяем, доступен ли ID
    if (premiumId.status !== 'available') {
      return res.status(400).json({ 
        message: 'Этот ID уже арендован. Выберите другой ID.' 
      });
    }
    
    // Проверяем, достаточно ли у пользователя кредитов
    const totalPrice = premiumId.price * months;
    if (user.credits < totalPrice) {
      return res.status(400).json({ 
        message: `Недостаточно кредитов. Нужно ${totalPrice}, а у вас ${user.credits}.` 
      });
    }
    
    // Обновляем данные пользователя и премиального ID
    user.credits -= totalPrice;
    user.premiumId = idValue;
    user.premiumIdExpiresAt = new Date(Date.now() + months * 30 * 24 * 60 * 60 * 1000);
    
    premiumId.status = 'rented';
    premiumId.currentOwner = userId;
    premiumId.rentedAt = new Date();
    premiumId.expiresAt = user.premiumIdExpiresAt;
    
    // Добавляем запись в историю аренды
    premiumId.rentHistory.push({
      user: userId,
      rentedAt: new Date(),
      expiredAt: user.premiumIdExpiresAt,
      price: totalPrice
    });
    
    // Сохраняем изменения
    await user.save();
    await premiumId.save();
    
    res.json({ 
      message: `Вы успешно арендовали ID "${idValue}" на ${months} месяц(ев)`,
      user: {
        id: user._id,
        username: user.username,
        credits: user.credits,
        premiumId: user.premiumId,
        premiumIdExpiresAt: user.premiumIdExpiresAt
      },
      premiumId
    });
  } catch (error) {
    console.error('Ошибка аренды премиального ID:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Продление аренды ID
exports.extendRental = async (req, res) => {
  try {
    const { idValue, months = 1 } = req.body;
    const userId = req.user.id;
    
    // Находим пользователя
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Находим премиальный ID
    const premiumId = await PremiumId.findOne({ idValue });
    if (!premiumId) {
      return res.status(404).json({ message: 'Премиальный ID не найден' });
    }
    
    // Проверяем, арендован ли ID текущим пользователем
    if (premiumId.currentOwner.toString() !== userId) {
      return res.status(403).json({ 
        message: 'Этот ID арендован другим пользователем или недоступен' 
      });
    }
    
    // Проверяем, достаточно ли у пользователя кредитов
    const totalPrice = premiumId.price * months;
    if (user.credits < totalPrice) {
      return res.status(400).json({ 
        message: `Недостаточно кредитов. Нужно ${totalPrice}, а у вас ${user.credits}.` 
      });
    }
    
    // Продляем аренду
    user.credits -= totalPrice;
    
    // Продлеваем срок аренды
    const newExpiryDate = user.premiumIdExpiresAt 
      ? new Date(user.premiumIdExpiresAt.getTime() + months * 30 * 24 * 60 * 60 * 1000)
      : new Date(Date.now() + months * 30 * 24 * 60 * 60 * 1000);
    
    user.premiumIdExpiresAt = newExpiryDate;
    premiumId.expiresAt = newExpiryDate;
    
    // Добавляем запись в историю аренды
    premiumId.rentHistory.push({
      user: userId,
      rentedAt: new Date(),
      expiredAt: newExpiryDate,
      price: totalPrice
    });
    
    // Сохраняем изменения
    await user.save();
    await premiumId.save();
    
    res.json({ 
      message: `Вы успешно продлили аренду ID "${idValue}" на ${months} месяц(ев)`,
      user: {
        id: user._id,
        username: user.username,
        credits: user.credits,
        premiumId: user.premiumId,
        premiumIdExpiresAt: user.premiumIdExpiresAt
      },
      premiumId
    });
  } catch (error) {
    console.error('Ошибка продления аренды:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Установка произвольного текста для ID
exports.setCustomIdText = async (req, res) => {
  try {
    const { customText } = req.body;
    const userId = req.user.id;
    
    // Проверяем валидность текста (можно добавить другие ограничения)
    if (!customText || customText.length < 3 || customText.length > 30) {
      return res.status(400).json({ 
        message: 'Текст ID должен содержать от 3 до 30 символов' 
      });
    }
    
    // Запрещенные слова и символы (можно расширить)
    const forbiddenWords = ['admin', 'moderator', 'support', 'system'];
    const forbiddenPattern = /[^\w\s\-\.]/; // разрешаем только буквы, цифры, пробелы, дефисы и точки
    
    if (forbiddenWords.some(word => customText.toLowerCase().includes(word))) {
      return res.status(400).json({ 
        message: 'Текст содержит запрещенные слова' 
      });
    }
    
    if (forbiddenPattern.test(customText)) {
      return res.status(400).json({ 
        message: 'Текст содержит запрещенные символы' 
      });
    }
    
    // Находим пользователя
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Проверяем, есть ли у пользователя активный премиальный ID
    if (!user.premiumId || !user.premiumIdExpiresAt || new Date() > user.premiumIdExpiresAt) {
      return res.status(403).json({ 
        message: 'У вас нет активного премиального ID. Сначала нужно арендовать ID.' 
      });
    }
    
    // Находим премиальный ID пользователя
    const premiumId = await PremiumId.findOne({ 
      idValue: user.premiumId,
      currentOwner: userId
    });
    
    if (!premiumId) {
      return res.status(404).json({ message: 'Премиальный ID не найден' });
    }
    
    // Обновляем текст ID
    premiumId.idValue = customText;
    user.premiumId = customText;
    
    // Сохраняем изменения
    await premiumId.save();
    await user.save();
    
    res.json({ 
      message: `Текст вашего ID успешно изменен на "${customText}"`,
      user: {
        id: user._id,
        username: user.username,
        premiumId: user.premiumId,
        premiumIdExpiresAt: user.premiumIdExpiresAt
      }
    });
  } catch (error) {
    console.error('Ошибка установки текста ID:', error.message);
    res.status(500).send('Ошибка сервера');
  }
}; 