const mongoose = require('mongoose');

const PremiumIdSchema = new mongoose.Schema({
  idValue: {
    type: String,
    required: true,
    unique: true
  },
  status: {
    type: String,
    enum: ['available', 'rented'],
    default: 'available'
  },
  price: {
    type: Number,
    required: true,
    default: 10 // Базовая цена за месяц в условных единицах
  },
  currentOwner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  rentedAt: {
    type: Date,
    default: null
  },
  expiresAt: {
    type: Date,
    default: null
  },
  rentHistory: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    rentedAt: Date,
    expiredAt: Date,
    price: Number
  }]
}, {
  timestamps: true
});

// Создаем индекс по дате истечения для эффективного поиска истекших ID
PremiumIdSchema.index({ expiresAt: 1 });

// Виртуальное свойство для проверки, истек ли срок аренды
PremiumIdSchema.virtual('isExpired').get(function() {
  if (!this.expiresAt) return false;
  return new Date() > this.expiresAt;
});

// Метод для продления аренды
PremiumIdSchema.methods.extendRental = async function(months = 1) {
  const newExpiryDate = this.expiresAt 
    ? new Date(this.expiresAt.getTime() + months * 30 * 24 * 60 * 60 * 1000)
    : new Date(Date.now() + months * 30 * 24 * 60 * 60 * 1000);
    
  this.expiresAt = newExpiryDate;
  return this.save();
};

module.exports = mongoose.model('PremiumId', PremiumIdSchema); 