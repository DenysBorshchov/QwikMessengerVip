const User = require('../models/User');

// Получение баланса кредитов пользователя
exports.getUserCredits = async (req, res) => {
  try {
    const userId = req.user.id;
    
    const user = await User.findById(userId).select('credits');
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    res.json({ credits: user.credits });
  } catch (error) {
    console.error('Ошибка получения баланса кредитов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Добавление кредитов пользователю (для тестирования и разработки)
exports.addCredits = async (req, res) => {
  try {
    const { userId, amount } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ message: 'Необходимо указать положительное количество кредитов' });
    }
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    user.credits += Number(amount);
    await user.save();
    
    res.json({ 
      message: `Добавлено ${amount} кредитов пользователю ${user.username}`,
      credits: user.credits
    });
  } catch (error) {
    console.error('Ошибка добавления кредитов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Имитация покупки кредитов
exports.purchaseCredits = async (req, res) => {
  try {
    const { packageId } = req.body;
    const userId = req.user.id;
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Пакеты кредитов (здесь можно добавить систему скидок)
    const packages = {
      'small': { credits: 100, price: 5 },   // $5 за 100 кредитов
      'medium': { credits: 300, price: 10 }, // $10 за 300 кредитов
      'large': { credits: 1000, price: 25 }  // $25 за 1000 кредитов
    };
    
    if (!packages[packageId]) {
      return res.status(400).json({ message: 'Указан неверный пакет кредитов' });
    }
    
    // В реальной системе здесь была бы интеграция с платежной системой
    // Например, Stripe, PayPal и т.д.
    
    // Имитируем успешную оплату
    const package = packages[packageId];
    user.credits += package.credits;
    await user.save();
    
    res.json({ 
      message: `Вы успешно приобрели ${package.credits} кредитов за $${package.price}`,
      credits: user.credits
    });
  } catch (error) {
    console.error('Ошибка покупки кредитов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Стоимость кредитов в разных пакетах (для информации)
exports.getCreditPackages = async (req, res) => {
  try {
    const packages = {
      'small': { credits: 100, price: 5 },   // $5 за 100 кредитов
      'medium': { credits: 300, price: 10 }, // $10 за 300 кредитов
      'large': { credits: 1000, price: 25 }  // $25 за 1000 кредитов
    };
    
    res.json({ packages });
  } catch (error) {
    console.error('Ошибка получения информации о пакетах кредитов:', error.message);
    res.status(500).send('Ошибка сервера');
  }
}; 