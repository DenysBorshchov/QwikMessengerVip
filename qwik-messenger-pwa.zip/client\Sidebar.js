import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FaSearch, FaSignOutAlt } from 'react-icons/fa';
import { useAuth } from '../contexts/AuthContext';
import { getAllUsers, searchUsers } from '../api/userApi';

const SidebarContainer = styled.div`
  width: 300px;
  height: 100%;
  background-color: #f0f2f5;
  border-right: 1px solid #ddd;
  display: flex;
  flex-direction: column;
`;

const Header = styled.div`
  padding: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #ddd;
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
`;

const Avatar = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
`;

const Username = styled.h3`
  font-size: 16px;
  font-weight: 500;
`;

const LogoutButton = styled.button`
  background: none;
  border: none;
  color: #666;
  cursor: pointer;
  font-size: 18px;
  
  &:hover {
    color: #e74c3c;
  }
`;

const SearchContainer = styled.div`
  padding: 10px 16px;
  position: relative;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 8px 12px 8px 40px;
  border-radius: 20px;
  border: none;
  background-color: #e6e6e6;
  font-size: 14px;
  
  &:focus {
    outline: none;
    background-color: white;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  }
`;

const SearchIcon = styled.div`
  position: absolute;
  left: 28px;
  top: 50%;
  transform: translateY(-50%);
  color: #666;
`;

const ContactsList = styled.div`
  flex: 1;
  overflow-y: auto;
`;

const ContactItem = styled.div`
  padding: 12px 16px;
  display: flex;
  align-items: center;
  cursor: pointer;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: #e6e6e6;
  }
  
  ${({ active }) => active && `
    background-color: #e6e6e6;
  `}
`;

const ContactAvatar = styled.img`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  margin-right: 12px;
`;

const ContactInfo = styled.div`
  flex: 1;
`;

const ContactName = styled.div`
  font-weight: 500;
  margin-bottom: 4px;
`;

const LastMessage = styled.div`
  font-size: 13px;
  color: #666;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const OnlineStatus = styled.div`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: ${({ online }) => (online ? '#4caf50' : '#bdbdbd')};
  margin-left: 8px;
`;

function Sidebar({ onSelectContact, selectedContactId }) {
  const [contacts, setContacts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredContacts, setFilteredContacts] = useState([]);
  
  const { currentUser, logout } = useAuth();
  
  // Загрузка контактов
  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const users = await getAllUsers();
        // Исключаем текущего пользователя из списка
        const filteredUsers = users.filter(user => user._id !== currentUser._id);
        setContacts(filteredUsers);
        setFilteredContacts(filteredUsers);
      } catch (error) {
        console.error('Ошибка при загрузке контактов:', error);
      }
    };
    
    fetchContacts();
  }, [currentUser]);
  
  // Фильтрация контактов при поиске
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredContacts(contacts);
    } else {
      const filtered = contacts.filter(contact => 
        contact.username.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredContacts(filtered);
    }
  }, [searchQuery, contacts]);
  
  // Обработка выхода из аккаунта
  const handleLogout = () => {
    logout();
  };
  
  return (
    <SidebarContainer>
      <Header>
        <UserInfo>
          <Avatar src={currentUser?.avatar} alt={currentUser?.username} />
          <Username>{currentUser?.username}</Username>
        </UserInfo>
        <LogoutButton onClick={handleLogout}>
          <FaSignOutAlt />
        </LogoutButton>
      </Header>
      
      <SearchContainer>
        <SearchIcon>
          <FaSearch />
        </SearchIcon>
        <SearchInput
          type="text"
          placeholder="Поиск контактов..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </SearchContainer>
      
      <ContactsList>
        {filteredContacts.map(contact => (
          <ContactItem
            key={contact._id}
            active={selectedContactId === contact._id}
            onClick={() => onSelectContact(contact)}
          >
            <ContactAvatar src={contact.avatar} alt={contact.username} />
            <ContactInfo>
              <ContactName>{contact.username}</ContactName>
              <LastMessage>
                {contact.lastMessage || 'Нет сообщений'}
              </LastMessage>
            </ContactInfo>
            <OnlineStatus online={contact.status === 'online'} />
          </ContactItem>
        ))}
      </ContactsList>
    </SidebarContainer>
  );
}

export default Sidebar; 