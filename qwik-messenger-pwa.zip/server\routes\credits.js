const express = require('express');
const router = express.Router();
const { 
  getUserCredits, 
  addCredits,
  purchaseCredits,
  getCreditPackages
} = require('../controllers/creditsController');
const { authenticateToken } = require('../middleware/auth');

// Получение баланса кредитов пользователя (требуется аутентификация)
router.get('/balance', authenticateToken, getUserCredits);

// Получение информации о доступных пакетах кредитов (публичный доступ)
router.get('/packages', getCreditPackages);

// Покупка кредитов (требуется аутентификация)
router.post('/purchase', authenticateToken, purchaseCredits);

// Добавление кредитов пользователю (только для администраторов)
// В реальной системе здесь нужно добавить проверку на роль администратора
router.post('/add', authenticateToken, addCredits);

module.exports = router; 