import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import styled from 'styled-components';

// Импорт страниц
import Login from './pages/Login';
import Register from './pages/Register';
import Chat from './pages/Chat';
import PremiumIds from './components/PremiumIds';
import Credits from './components/Credits';
import NavBar from './components/NavBar';
import MobileChat from './components/MobileChat';
import MobileNavBar from './components/MobileNavBar';

// Стили для адаптивного контейнера
const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

const Content = styled.div`
  flex: 1;
  padding: ${props => props.isMobile ? '8px' : '20px'};
  margin-top: ${props => props.isMobile ? '60px' : '70px'};
`;

// Защищенный маршрут
const ProtectedRoute = ({ children }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  return children;
};

function App() {
  const [isMobile, setIsMobile] = useState(false);
  
  // Определяем, является ли устройство мобильным
  useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    // Проверяем при загрузке
    checkIsMobile();
    
    // Проверяем при изменении размера окна
    window.addEventListener('resize', checkIsMobile);
    
    return () => {
      window.removeEventListener('resize', checkIsMobile);
    };
  }, []);

  // Рендерим мобильную или десктопную версию
  const renderChatComponent = () => {
    if (isMobile) {
      return <MobileChat />;
    } else {
      return <Chat />;
    }
  };

  return (
    <AuthProvider>
      <AppContainer>
        {isMobile ? <MobileNavBar /> : <NavBar />}
        <Content isMobile={isMobile}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route 
              path="/" 
              element={
                <ProtectedRoute>
                  {renderChatComponent()}
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/premium-ids" 
              element={
                <ProtectedRoute>
                  <PremiumIds />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/credits" 
              element={
                <ProtectedRoute>
                  <Credits />
                </ProtectedRoute>
              } 
            />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Content>
      </AppContainer>
    </AuthProvider>
  );
}

export default App; 