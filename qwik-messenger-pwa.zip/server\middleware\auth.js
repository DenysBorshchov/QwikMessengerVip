const jwt = require('jsonwebtoken');

exports.authenticateToken = (req, res, next) => {
  // Получаем токен из заголовка
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ message: 'Требуется авторизация' });
  }

  try {
    // Верифицируем токен
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (error) {
    console.error('Ошибка аутентификации:', error.message);
    return res.status(403).json({ message: 'Неверный токен' });
  }
}; 