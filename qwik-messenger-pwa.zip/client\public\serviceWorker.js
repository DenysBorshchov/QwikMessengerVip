// Имя кэша
const CACHE_NAME = 'qwik-messenger-v1';

// Ресурсы для предварительного кэширования
const urlsToCache = [
  '/',
  '/index.html',
  '/static/js/main.chunk.js',
  '/static/js/0.chunk.js',
  '/static/js/bundle.js',
  '/manifest.json',
  '/favicon.svg',
  '/icons/icon-192.svg',
  '/icons/icon-512.svg',
  'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap'
];

// Установка Service Worker и кэширование статических ресурсов
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
  // Принудительная активация, минуя состояние ожидания
  self.skipWaiting();
});

// Активация Service Worker и удаление старых кэшей
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            // Если найден старый кэш, удаляем его
            return caches.delete(cacheName);
          }
          return null;
        })
      );
    })
  );
  // Контроль над клиентскими страницами сразу после активации
  self.clients.claim();
});

// Стратегия сетевого перехвата
self.addEventListener('fetch', event => {
  // Игнорируем запросы к API, они не должны кэшироваться
  if (event.request.url.includes('/api/')) {
    return;
  }
  
  // Стратегия Network First для HTML документов (навигация)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          return caches.match('/index.html');
        })
    );
    return;
  }
  
  // Для остальных ресурсов используем стратегию Cache First
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Если ресурс найден в кэше, возвращаем его
        if (response) {
          return response;
        }
        
        // Иначе делаем запрос к сети и кэшируем результат
        return fetch(event.request)
          .then(netResponse => {
            // Проверяем валидность ответа
            if (!netResponse || netResponse.status !== 200 || netResponse.type !== 'basic') {
              return netResponse;
            }
            
            // Кэшируем новый ресурс (создаем копию)
            const responseToCache = netResponse.clone();
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            
            return netResponse;
          })
          .catch(() => {
            // Если запрос к картинке и он не доступен, можно вернуть заглушку
            if (event.request.url.match(/\.(jpg|jpeg|png|gif|svg)$/)) {
              return caches.match('/icons/offline-image.svg');
            }
            return new Response('Нет соединения с интернетом', {
              status: 503,
              statusText: 'Сервис недоступен'
            });
          });
      })
  );
});

// Обработка фоновой синхронизации
self.addEventListener('sync', event => {
  if (event.tag === 'syncMessages') {
    event.waitUntil(syncMessages());
  }
});

// Функция синхронизации сообщений
async function syncMessages() {
  try {
    // Запрашиваем неотправленные сообщения из IndexedDB
    const db = await openDB();
    const unsentMessages = await db.getAll('unsentMessages');
    
    // Если есть неотправленные сообщения, пытаемся их отправить
    if (unsentMessages.length > 0) {
      for (const message of unsentMessages) {
        try {
          const response = await fetch('/api/messages', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${message.token}`
            },
            body: JSON.stringify(message.data)
          });
          
          if (response.ok) {
            // Если сообщение успешно отправлено, удаляем его из хранилища
            await db.delete('unsentMessages', message.id);
          }
        } catch (error) {
          console.error('Ошибка при синхронизации сообщения:', error);
        }
      }
    }
  } catch (error) {
    console.error('Ошибка при синхронизации сообщений:', error);
  }
}

// Функция для открытия IndexedDB
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('qwikMessenger', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('unsentMessages')) {
        db.createObjectStore('unsentMessages', { keyPath: 'id', autoIncrement: true });
      }
    };
  });
}

// Обработка push-уведомлений
self.addEventListener('push', event => {
  const data = event.data.json();
  
  const options = {
    body: data.message,
    icon: '/icons/icon-192.svg',
    badge: '/icons/notification-badge.svg',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title || 'Новое сообщение', options)
  );
});

// Обработка клика по уведомлению
self.addEventListener('notificationclick', event => {
  event.notification.close();
  
  // Переход по URL при клике на уведомление
  event.waitUntil(
    clients.matchAll({ type: 'window' })
      .then(clientList => {
        // Проверяем, открыто ли уже приложение
        for (const client of clientList) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            return client.focus();
          }
        }
        // Если нет, открываем новое окно
        if (clients.openWindow) {
          return clients.openWindow(event.notification.data.url);
        }
      })
  );
}); 