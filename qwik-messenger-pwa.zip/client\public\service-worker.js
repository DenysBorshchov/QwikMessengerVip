const CACHE_NAME = 'qwik-messenger-v1';
const CACHE_URLS = [
  '/',
  '/index.html',
  '/static/js/bundle.js',
  '/manifest.json',
  '/favicon.svg',
  '/icon-192.svg',
  '/icon-512.svg'
];

// Установка Service Worker и кэширование необходимых ресурсов
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Открыт кэш');
        return cache.addAll(CACHE_URLS);
      })
  );
});

// Активация Service Worker
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('Удаление старого кэша:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Обработка запросов
self.addEventListener('fetch', event => {
  event.respondWith(
    // Пытаемся найти ответ в кэше
    caches.match(event.request)
      .then(response => {
        // Если ответ найден в кэше, возвращаем его
        if (response) {
          return response;
        }
        
        // Иначе делаем запрос к сети
        return fetch(event.request)
          .then(response => {
            // Проверяем, что получили корректный ответ
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Клонируем ответ, так как body stream может быть использован только один раз
            const responseToCache = response.clone();
            
            // Открываем кэш и добавляем в него новый ответ
            caches.open(CACHE_NAME)
              .then(cache => {
                // Не кэшируем API запросы
                if (!event.request.url.includes('/api/')) {
                  cache.put(event.request, responseToCache);
                }
              });
              
            return response;
          })
          .catch(error => {
            // Если произошла ошибка сети и запрашивается страница, показываем офлайн страницу
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/index.html');
            }
            
            console.error('Ошибка выполнения запроса:', error);
          });
      })
  );
});

// Обработка синхронизации - отправка накопленных сообщений, когда появляется интернет
self.addEventListener('sync', event => {
  if (event.tag === 'syncMessages') {
    event.waitUntil(syncMessages());
  }
});

// Функция синхронизации сообщений
function syncMessages() {
  return getUnsentMessages()
    .then(messages => {
      return Promise.all(messages.map(message => {
        return fetch('http://localhost:5000/api/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${message.token}`
          },
          body: JSON.stringify(message.data)
        })
        .then(response => {
          if (response.ok) {
            return deleteMessageFromIndexedDB(message.id);
          }
        })
        .catch(error => {
          console.error('Ошибка отправки сообщения при синхронизации:', error);
        });
      }));
    });
}

// Получение неотправленных сообщений из IndexedDB
function getUnsentMessages() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('qwikMessenger', 1);
    
    request.onerror = event => {
      reject('Ошибка при открытии базы данных');
    };
    
    request.onsuccess = event => {
      const db = event.target.result;
      const transaction = db.transaction(['unsentMessages'], 'readonly');
      const store = transaction.objectStore('unsentMessages');
      const messages = [];
      
      store.openCursor().onsuccess = event => {
        const cursor = event.target.result;
        
        if (cursor) {
          messages.push({
            id: cursor.key,
            data: cursor.value.data,
            token: cursor.value.token
          });
          cursor.continue();
        } else {
          resolve(messages);
        }
      };
    };
  });
}

// Удаление отправленного сообщения из IndexedDB
function deleteMessageFromIndexedDB(id) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('qwikMessenger', 1);
    
    request.onsuccess = event => {
      const db = event.target.result;
      const transaction = db.transaction(['unsentMessages'], 'readwrite');
      const store = transaction.objectStore('unsentMessages');
      
      const deleteRequest = store.delete(id);
      
      deleteRequest.onsuccess = () => {
        resolve();
      };
      
      deleteRequest.onerror = () => {
        reject('Ошибка при удалении сообщения из IndexedDB');
      };
    };
  });
}

// Обработка push-уведомлений
self.addEventListener('push', event => {
  if (event.data) {
    const data = event.data.json();
    
    const options = {
      body: data.content,
      icon: '/icon-192.svg',
      badge: '/icon-192.svg',
      vibrate: [100, 50, 100],
      data: {
        url: '/'
      }
    };
    
    event.waitUntil(
      self.registration.showNotification('Qwik Messenger', options)
    );
  }
});

// Обработка клика по уведомлению
self.addEventListener('notificationclick', event => {
  event.notification.close();
  
  event.waitUntil(
    clients.matchAll({
      type: 'window'
    })
    .then(clientList => {
      if (clientList.length > 0) {
        return clientList[0].focus();
      }
      
      return clients.openWindow(event.notification.data.url);
    })
  );
}); 