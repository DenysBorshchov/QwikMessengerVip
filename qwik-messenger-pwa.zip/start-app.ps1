# Скрипт для запуска Qwik Messenger
Write-Host "Запуск Qwik Messenger..." -ForegroundColor Cyan

# Запуск сервера
Write-Host "Запуск серверной части..." -ForegroundColor Green
Start-Process -FilePath "powershell" -ArgumentList "-Command", "cd $PSScriptRoot/server; npm install; npm start"

# Даем серверу время запуститься
Start-Sleep -Seconds 5

# Запуск клиента
Write-Host "Запуск клиентской части..." -ForegroundColor Green
Start-Process -FilePath "powershell" -ArgumentList "-Command", "cd $PSScriptRoot/client; npm install; npm start"

Write-Host "Qwik Messenger запущен!" -ForegroundColor Cyan
Write-Host "Для доступа к приложению откройте браузер и перейдите по адресу: http://localhost:3000" -ForegroundColor Yellow 