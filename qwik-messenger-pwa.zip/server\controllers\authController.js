const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Регистрация нового пользователя
exports.registerUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Проверка существования пользователя
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
    }

    user = await User.findOne({ username });
    if (user) {
      return res.status(400).json({ message: 'Пользователь с таким именем уже существует' });
    }

    // Создание нового пользователя
    user = new User({
      username,
      email,
      password
    });

    // Хеширование пароля
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);

    await user.save();

    // Создание JWT токена
    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '24h' },
      (err, token) => {
        if (err) throw err;
        res.json({ token, user: { id: user.id, username: user.username, email: user.email } });
      }
    );
  } catch (error) {
    console.error('Ошибка регистрации:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Вход пользователя
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Проверка существования пользователя
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Неверные учетные данные' });
    }

    // Проверка пароля
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Неверные учетные данные' });
    }

    // Создание JWT токена
    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '24h' },
      (err, token) => {
        if (err) throw err;
        res.json({ token, user: { id: user.id, username: user.username, email: user.email } });
      }
    );
  } catch (error) {
    console.error('Ошибка входа:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Получение данных текущего пользователя
exports.getCurrentUser = async (req, res) => {
  try {
    // В req.user должен быть доступен ID пользователя благодаря middleware аутентификации
    const userId = req.user.id;
    
    // Находим пользователя по ID и исключаем пароль из результата
    const user = await User.findById(userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    // Проверяем, не истек ли срок действия премиального ID
    if (user.premiumId && user.premiumIdExpiresAt && user.premiumIdExpiresAt < new Date()) {
      // Если срок истек, очищаем premiumId и premiumIdExpiresAt
      user.premiumId = null;
      user.premiumIdExpiresAt = null;
      await user.save();
    }
    
    res.json(user);
  } catch (error) {
    console.error('Ошибка получения данных пользователя:', error);
    console.error('Ошибка получения пользователя:', error.message);
    res.status(500).send('Ошибка сервера');
  }
}; 