const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');

// Список размеров иконок для генерации
const sizes = [16, 32, 64, 192, 512];

// Путь к SVG файлу
const svgPath = path.join(__dirname, 'qwik-icon.svg');

// Функция для создания PNG иконки нужного размера
async function generatePngIcon(size) {
  try {
    // Создаем canvas нужного размера
    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    
    // Загружаем SVG изображение
    const img = await loadImage(svgPath);
    
    // Рисуем изображение на canvas
    ctx.drawImage(img, 0, 0, size, size);
    
    // Сохраняем изображение в файл
    const outputPath = path.join(__dirname, `icon-${size}.png`);
    const out = fs.createWriteStream(outputPath);
    const stream = canvas.createPNGStream();
    
    stream.pipe(out);
    
    out.on('finish', () => {
      console.log(`✅ Создана иконка ${size}x${size}px: ${outputPath}`);
      
      // Создаем копию для использования в manifest.json
      if (size === 192 || size === 512) {
        const manifestPath = path.join(__dirname, `icon-${size}.png`);
        fs.copyFileSync(outputPath, manifestPath);
        console.log(`✅ Скопирована иконка для manifest: ${manifestPath}`);
      }
      
      // Создаем favicon.ico из иконки 32x32
      if (size === 32) {
        const faviconPath = path.join(__dirname, '..', 'favicon.ico');
        fs.copyFileSync(outputPath, faviconPath);
        console.log(`✅ Создан favicon.ico: ${faviconPath}`);
      }
    });
  } catch (error) {
    console.error(`❌ Ошибка при создании иконки ${size}x${size}:`, error);
  }
}

// Главная функция
async function generateAllIcons() {
  console.log('🚀 Начинаю генерацию иконок для Qwik Мессенджера...');
  
  // Создаем иконки всех размеров
  for (const size of sizes) {
    await generatePngIcon(size);
  }
  
  console.log('✨ Генерация иконок завершена!');
  console.log('📝 ПРИМЕЧАНИЕ: Для запуска этого скрипта необходимо установить npm-пакет "canvas"');
  console.log('📝 Выполните: npm install canvas --save-dev');
}

// Запускаем генерацию иконок
generateAllIcons(); 