import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../contexts/AuthContext';
import styled from 'styled-components';

// Стилизованные компоненты
const Container = styled.div`
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  @media (max-width: 768px) {
    padding: 15px;
    border-radius: 8px;
  }
`;

const Title = styled.h2`
  color: #4a6ee0;
  margin-bottom: 20px;
  
  @media (max-width: 768px) {
    margin-bottom: 15px;
  }
`;

const PackageList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 15px;
  margin: 20px 0 30px;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 12px;
    margin: 15px 0 20px;
  }
`;

const PackageCard = styled.div`
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  background-color: #f9fbff;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  position: relative;
  overflow: hidden;
  
  ${props => props.popular && `
    border-color: #4a6ee0;
    box-shadow: 0 4px 12px rgba(74, 110, 224, 0.15);
    
    &::before {
      content: 'Популярный';
      position: absolute;
      top: 10px;
      right: -30px;
      background-color: #4a6ee0;
      color: white;
      padding: 5px 40px;
      transform: rotate(45deg);
      font-size: 12px;
    }
  `}
  
  &:hover {
    border-color: #4a6ee0;
    box-shadow: 0 2px 8px rgba(74, 110, 224, 0.2);
  }
  
  @media (max-width: 768px) {
    padding: 15px;
    
    ${props => props.popular && `
      &::before {
        top: 5px;
        right: -35px;
        padding: 3px 40px;
        font-size: 10px;
      }
    `}
  }
`;

const PackageTitle = styled.h3`
  color: #333;
  margin-bottom: 10px;
  
  @media (max-width: 768px) {
    margin-bottom: 5px;
  }
`;

const PackageCredits = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #4a6ee0;
  margin: 5px 0;
  
  @media (max-width: 768px) {
    font-size: 20px;
  }
`;

const PackagePrice = styled.div`
  color: #666;
  margin-bottom: 15px;
  
  @media (max-width: 768px) {
    margin-bottom: 10px;
  }
`;

const Button = styled.button`
  background-color: #4a6ee0;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;
  width: 100%;
  margin-top: auto;

  &:hover {
    background-color: #3757b6;
  }

  &:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
  }
  
  @media (max-width: 768px) {
    padding: 12px 20px; /* Увеличиваем высоту кнопки для лучшей тактильной зоны */
  }
`;

const InfoBox = styled.div`
  background-color: #f5f7ff;
  border: 1px solid #d0d9ff;
  border-radius: 5px;
  padding: 15px;
  margin: 20px 0;
  
  @media (max-width: 768px) {
    padding: 12px;
    margin: 15px 0;
    font-size: 13px;
  }
`;

const UserBalance = styled.h3`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 15px;
    
    span {
      margin-bottom: 10px;
    }
  }
`;

const MobileButton = styled(Button)`
  @media (max-width: 768px) {
    display: block;
    width: 100%;
    margin-top: 10px;
  }
`;

const Credits = () => {
  const { user, updateUserData } = useContext(AuthContext);
  const [packages, setPackages] = useState([]);
  const [userCredits, setUserCredits] = useState(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Загрузка пакетов кредитов и баланса пользователя
  useEffect(() => {
    // Получаем пакеты кредитов
    axios.get('http://localhost:5000/api/credits/packages')
      .then(response => {
        // Преобразуем объект пакетов в массив для отображения
        const packagesArray = Object.entries(response.data.packages).map(([id, data]) => ({
          id,
          ...data,
          // Помечаем пакет medium как популярный
          popular: id === 'medium'
        }));
        
        setPackages(packagesArray);
      })
      .catch(error => {
        console.error('Ошибка получения пакетов кредитов:', error);
        setMessage('Не удалось загрузить доступные пакеты кредитов');
      });
    
    // Если пользователь авторизован, получаем его баланс кредитов
    if (user && localStorage.getItem('token')) {
      axios.get('http://localhost:5000/api/credits/balance', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
        .then(response => {
          setUserCredits(response.data.credits);
        })
        .catch(error => {
          console.error('Ошибка получения баланса кредитов:', error);
        });
    }
  }, [user]);

  // Покупка пакета кредитов
  const purchaseCredits = (packageId) => {
    if (!user) {
      setMessage('Для покупки кредитов необходимо войти в систему');
      return;
    }
    
    setLoading(true);
    
    axios.post('http://localhost:5000/api/credits/purchase', {
      packageId
    }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
      .then(response => {
        // Обновляем баланс кредитов
        setUserCredits(response.data.credits);
        
        // Обновляем данные пользователя в контексте
        if (updateUserData) {
          updateUserData({ ...user, credits: response.data.credits });
        }
        
        // Показываем сообщение об успешной покупке
        setMessage(response.data.message);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          setMessage(error.response.data.message);
        } else {
          setMessage('Произошла ошибка при покупке кредитов');
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <Container>
      <Title>Пополнение кредитов</Title>
      
      {user ? (
        <div>
          <UserBalance>
            <span>Ваш текущий баланс: {userCredits} кредитов</span>
          </UserBalance>
          
          {message && (
            <InfoBox>
              {message}
            </InfoBox>
          )}
          
          <h3>Выберите пакет кредитов:</h3>
          
          <PackageList>
            {packages.map(pkg => (
              <PackageCard key={pkg.id} popular={pkg.popular}>
                <PackageTitle>
                  {pkg.id === 'small' && 'Базовый'}
                  {pkg.id === 'medium' && 'Стандартный'}
                  {pkg.id === 'large' && 'Премиум'}
                </PackageTitle>
                <PackageCredits>{pkg.credits} кредитов</PackageCredits>
                <PackagePrice>${pkg.price}</PackagePrice>
                <Button 
                  onClick={() => purchaseCredits(pkg.id)} 
                  disabled={loading}
                >
                  {loading ? 'Обработка...' : 'Купить'}
                </Button>
              </PackageCard>
            ))}
          </PackageList>
          
          <InfoBox>
            <p>
              Кредиты используются для аренды премиальных ID и других функций в приложении.
              Чем больше кредитов вы покупаете за раз, тем выгоднее цена.
            </p>
            <p>
              В реальном приложении здесь была бы интеграция с платежной системой (Stripe, PayPal и т.д.).
              В этой демо-версии покупка кредитов имитируется без реальной оплаты.
            </p>
          </InfoBox>
        </div>
      ) : (
        <InfoBox>
          Для покупки кредитов необходимо войти в систему. Пожалуйста, войдите или зарегистрируйтесь.
        </InfoBox>
      )}
    </Container>
  );
};

export default Credits; 