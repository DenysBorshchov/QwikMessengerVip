const Message = require('../models/Message');
const User = require('../models/User');

// Получение сообщений между двумя пользователями
exports.getMessages = async (req, res) => {
  try {
    const { userId, receiverId } = req.params;

    // Поиск сообщений в обоих направлениях
    const messages = await Message.find({
      $or: [
        { sender: userId, receiver: receiverId },
        { sender: receiverId, receiver: userId }
      ]
    }).sort({ createdAt: 1 }); // Сортировка по времени создания

    res.json(messages);
  } catch (error) {
    console.error('Ошибка получения сообщений:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Отправка сообщения
exports.sendMessage = async (req, res) => {
  try {
    const { sender, receiver, content } = req.body;

    // Проверка существования пользователей
    const senderExists = await User.findById(sender);
    const receiverExists = await User.findById(receiver);

    if (!senderExists || !receiverExists) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    // Создание нового сообщения
    const newMessage = new Message({
      sender,
      receiver,
      content
    });

    const savedMessage = await newMessage.save();
    res.status(201).json(savedMessage);
  } catch (error) {
    console.error('Ошибка отправки сообщения:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Получение списка переписок пользователя
exports.getConversations = async (req, res) => {
  try {
    const { userId } = req.params;

    // Находим все сообщения, где пользователь является отправителем или получателем
    const messages = await Message.find({
      $or: [
        { sender: userId },
        { receiver: userId }
      ]
    }).sort({ createdAt: -1 }); // Сортировка по убыванию времени

    // Формируем список уникальных пользователей, с которыми есть переписка
    const conversations = {};
    const userIds = new Set();

    for (const message of messages) {
      // Определяем ID собеседника (не текущего пользователя)
      const otherUserId = message.sender.toString() === userId 
        ? message.receiver.toString() 
        : message.sender.toString();
      
      // Если этот собеседник ещё не добавлен в список, добавляем его
      if (!conversations[otherUserId]) {
        userIds.add(otherUserId);
        conversations[otherUserId] = {
          lastMessage: message.content,
          timestamp: message.createdAt
        };
      }
    }

    // Получаем информацию о пользователях
    const users = await User.find({
      _id: { $in: Array.from(userIds) }
    }).select('username avatar status');

    // Формируем окончательный список переписок
    const result = users.map(user => ({
      user: {
        id: user._id,
        username: user.username,
        avatar: user.avatar,
        status: user.status
      },
      lastMessage: conversations[user._id.toString()].lastMessage,
      timestamp: conversations[user._id.toString()].timestamp
    }));

    res.json(result);
  } catch (error) {
    console.error('Ошибка получения переписок:', error.message);
    res.status(500).send('Ошибка сервера');
  }
};

// Удаление сообщения (для текущего пользователя)
exports.deleteMessage = async (req, res) => {
  try {
    const userId = req.user._id;
    const { messageId } = req.params;
    
    // Находим сообщение
    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({ message: 'Сообщение не найдено' });
    }
    
    // Проверяем, принадлежит ли сообщение пользователю
    if (message.sender.toString() !== userId.toString() && 
        message.receiver.toString() !== userId.toString()) {
      return res.status(403).json({ message: 'Нет доступа к этому сообщению' });
    }
    
    // Добавляем пользователя в массив deletedFor
    message.deletedFor.push(userId);
    await message.save();
    
    res.json({ message: 'Сообщение успешно удалено' });
  } catch (error) {
    console.error('Ошибка при удалении сообщения:', error);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
}; 