import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import { io } from 'socket.io-client';
import { useAuth } from '../contexts/AuthContext';
import Sidebar from '../components/Sidebar';
import ChatBox from '../components/ChatBox';

const ChatContainer = styled.div`
  display: flex;
  height: 100vh;
  width: 100%;
`;

function Chat() {
  const [selectedContact, setSelectedContact] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState({});
  
  const { currentUser } = useAuth();
  const socket = useRef();
  
  // Инициализация Socket.io
  useEffect(() => {
    socket.current = io('http://localhost:5000');
    
    // Отправляем ID пользователя при подключении
    socket.current.emit('user_connected', currentUser._id);
    
    // Обработка статуса пользователей
    socket.current.on('user_status', (data) => {
      setOnlineUsers(prev => ({
        ...prev,
        [data.userId]: data.status
      }));
    });
    
    // Обработка получения сообщения
    socket.current.on('receive_message', (data) => {
      console.log('Получено новое сообщение:', data);
      // Здесь можно обновить список сообщений или показать уведомление
    });
    
    return () => {
      socket.current.disconnect();
    };
  }, [currentUser]);
  
  // Обработка выбора контакта
  const handleSelectContact = (contact) => {
    // Обновляем статус контакта из онлайн-списка
    const updatedContact = {
      ...contact,
      status: onlineUsers[contact._id] || 'offline'
    };
    setSelectedContact(updatedContact);
  };
  
  return (
    <ChatContainer>
      <Sidebar 
        onSelectContact={handleSelectContact} 
        selectedContactId={selectedContact?._id}
      />
      <ChatBox 
        selectedContact={selectedContact} 
        socket={socket.current}
      />
    </ChatContainer>
  );
}

export default Chat; 