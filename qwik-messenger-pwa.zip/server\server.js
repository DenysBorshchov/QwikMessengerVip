const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const http = require('http');
const { Server } = require('socket.io');
const authRoutes = require('./routes/auth');
const messageRoutes = require('./routes/messages');
const premiumIdRoutes = require('./routes/premiumIds');
const creditRoutes = require('./routes/credits');
const { authenticateToken } = require('./middleware/auth');
const { initializePremiumIds } = require('./utils/initData');

// Загрузка переменных окружения
dotenv.config();

// Инициализация Express
const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Подключение к MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('MongoDB подключена');
  // Инициализация премиальных ID при запуске
  initializePremiumIds();
})
.catch(err => console.error('Ошибка подключения к MongoDB:', err));

// HTTP сервер
const server = http.createServer(app);

// Настройка Socket.IO
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Обработка событий сокетов
io.on('connection', (socket) => {
  console.log('Пользователь подключился:', socket.id);
  
  socket.on('join', (userId) => {
    socket.join(userId);
    console.log(`Пользователь ${userId} присоединился к своей комнате`);
  });
  
  socket.on('sendMessage', (messageData) => {
    io.to(messageData.receiver).emit('newMessage', messageData);
    console.log(`Сообщение отправлено от ${messageData.sender} к ${messageData.receiver}`);
  });
  
  socket.on('disconnect', () => {
    console.log('Пользователь отключился:', socket.id);
  });
});

// Маршруты API
app.use('/api/auth', authRoutes);
app.use('/api/messages', authenticateToken, messageRoutes);
app.use('/api/premium-ids', premiumIdRoutes);
app.use('/api/credits', creditRoutes);

// Запуск сервера
server.listen(port, () => {
  console.log(`Сервер запущен на порту ${port}`);
}); 