/**
 * Этот скрипт генерирует данные иконки в формате Base64.
 * После запуска скрипта результат можно расшифровать и сохранить как PNG файл.
 */

// Минимальная PNG иконка, закодированная в Base64
// Эта иконка представляет букву Q на синем фоне
const base64Icon32x32 = `
iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAF
u2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0w
TXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRh
LyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEz
LTE2OjQwOjIyICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcv
MTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIi
IHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6ZGM9Imh0dHA6
Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5h
ZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29t
L3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NU
eXBlL1Jlc291cmNlRXZlbnQjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAy
MDE5IChXaW5kb3dzKSIgeG1wOkNyZWF0ZURhdGU9IjIwMjQtMDMtMDFUMDc6MjE6NDQrMDI6MDAi
IHhtcDpNb2RpZnlEYXRlPSIyMDI0LTAzLTAxVDA3OjIzOjQxKzAyOjAwIiB4bXA6TWV0YWRhdGFE
YXRlPSIyMDI0LTAzLTAxVDA3OjIzOjQxKzAyOjAwIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgcGhv
dG9zaG9wOkNvbG9yTW9kZT0iMyIgcGhvdG9zaG9wOklDQ1Byb2ZpbGU9InNSR0IgSUVDNjE5NjYt
Mi4xIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjYxZmM2NGUwLTMxYjAtNDQ0ZC1iNDEzLWZk
NDY1YTllZmYyYiIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjA3Mzg0
MzBmLTMxYzQtMmI0NS1hMTUxLWJiM2MxMTVmMzljMSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElE
PSJ4bXAuZGlkOjkwZGVlMzE3LTk2NTMtY2Q0OS05NTg0LTk0MmYwNDFkODNlNCI+IDx4bXBNTTpI
aXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omlu
c3RhbmNlSUQ9InhtcC5paWQ6OTBkZWUzMTctOTY1My1jZDQ5LTk1ODQtOTQyZjA0MWQ4M2U0IiBz
dEV2dDp3aGVuPSIyMDI0LTAzLTAxVDA3OjIxOjQ0KzAyOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50
PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiLz4gPHJkZjpsaSBzdEV2dDphY3Rp
b249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjYxZmM2NGUwLTMxYjAtNDQ0ZC1i
NDEzLWZkNDY1YTllZmYyYiIgc3RFdnQ6d2hlbj0iMjAyNC0wMy0wMVQwNzoyMzo0MSswMjowMCIg
c3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIiBz
dEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNj
cmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Ph0mQIAA
AAKHSURBVFiFvZdNaBNBFMf/M5tskm6a3W1smpRoghQq1YMfoBxEQVBQEMGTUDx48R5QvHvz5Klg
QQVRUEEUQS+Kh4IHP/DgQSwKra1V29gPk6ZudjPZ8ZA2Tdmkm91k0x8MzLyZnf3Pe2/ezCxhjMFG
iBUWVIHBRnA7QNuAwZdFtXhZGnRzMztAkjkIIfj8RUF2qEZCAVlgUQyqNesEuoMUhzvpf4EUH1Qx
NJ5FUqQoM2DTsI+gP0CxKUAQobYKhDhCsD3KbX4Kx4UcEpTF74y7nL2YhIoPUjdFRVOoJ8Clxifw
9nrMjuBjpILg1+ey5rG/TdAUCHEEuzeZy7w2SQUYHl/PmieNE2Ov+eoKMKAvWVUKhTk5fqZlxRiR
0Ggg03sRVbVoicBAXxhXD1krS+RrfbQsQDkCz5rdwTgG+kL4zrKIzdXmzIzU5GAIxPcCAPqzJTzN
/IX/Wxab4zEcamM1PpuZS1XndEPPgYgq4sK5GD6dOIQzvVFc2xwFH/DV+OwK5IwKLCxoyLw+vGQr
qSoGY2HwwdoS8wJPpvKYnTNe0VWBZEpCrujMMrqrUNdFIQZ6cX9iBve+/UCu6Gyxu47A5EwJzx8+
wdEfWRB9ZE2TM14yZ8y7zP6vMsYeZJGcW9SEGQWMwTXW2AeCqmLsYQ4/5/ObdSw7GbOPxI1b4zLu
P00gm1Os3VYfR9yRwsDQmMfEZSFYZD0CADDw4s2svCwEAGDo0ZCPazbkHglLMLFTAe7Y2Wt/DYYH
75XWP4HB4ftl+wL33hXtC9x5XbYvcOu1H56a0DuIE7FvgUu9lfUr4ERATq1jgXKl6kxA1VjtWXAf
Nm9GXWD6l+HfkPEH+q61Ju8U+tAAAAAASUVORK5CYII=
`;

// Функция для декодирования Base64 и сохранения в файл
function generateIconFromBase64() {
  const fs = require('fs');
  const path = require('path');
  
  // Сначала очистим строку от пробелов и переносов строк
  const cleanBase64 = base64Icon32x32.replace(/\s/g, '');
  
  // Сохраняем как PNG файл
  const pngPath = path.join(__dirname, '..', 'favicon.ico');
  fs.writeFileSync(pngPath, Buffer.from(cleanBase64, 'base64'));
  
  console.log(`✅ Иконка создана и сохранена: ${pngPath}`);
  
  // Создаем также копию для manifest.json
  fs.copyFileSync(pngPath, path.join(__dirname, 'icon-32.png'));
  console.log(`✅ Скопирована иконка: ${path.join(__dirname, 'icon-32.png')}`);
  
  // Масштабированные версии (просто копируем тот же файл)
  const sizes = [16, 64, 192, 512];
  for (const size of sizes) {
    const sizePath = path.join(__dirname, `icon-${size}.png`);
    fs.copyFileSync(pngPath, sizePath);
    console.log(`✅ Скопирована иконка: ${sizePath}`);
  }
}

// Запускаем генерацию иконки
console.log('🚀 Создаю иконку Qwik из Base64 данных...');
generateIconFromBase64();
console.log('✨ Готово! Иконка создана и готова к использованию.'); 