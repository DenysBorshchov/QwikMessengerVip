import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../contexts/AuthContext';
import styled from 'styled-components';

// Стилизованные компоненты
const Container = styled.div`
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  
  @media (max-width: 768px) {
    padding: 15px;
    border-radius: 8px;
  }
`;

const Title = styled.h2`
  color: #4a6ee0;
  margin-bottom: 20px;
  
  @media (max-width: 768px) {
    margin-bottom: 15px;
  }
`;

const IdList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 15px;
  margin-bottom: 30px;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fill, minmax(100%, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }
`;

const IdCard = styled.div`
  padding: 15px;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  background-color: ${props => props.highlight ? '#f0f5ff' : '#ffffff'};
  display: flex;
  flex-direction: column;
  position: relative;

  &:hover {
    border-color: #4a6ee0;
    box-shadow: 0 2px 8px rgba(74, 110, 224, 0.2);
  }
  
  @media (max-width: 768px) {
    padding: 12px;
  }
`;

const IdName = styled.h3`
  color: #333;
  margin-bottom: 5px;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const IdPrice = styled.p`
  color: #666;
  font-weight: bold;
`;

const Button = styled.button`
  background-color: #4a6ee0;
  color: white;
  border: none;
  padding: 8px 15px;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 10px;
  transition: background-color 0.2s;

  &:hover {
    background-color: #3757b6;
  }

  &:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
  }
  
  @media (max-width: 768px) {
    padding: 12px 15px; /* Увеличиваем высоту кнопки для лучшей тактильной зоны */
  }
`;

const InfoBox = styled.div`
  background-color: #f5f7ff;
  border: 1px solid #d0d9ff;
  border-radius: 5px;
  padding: 15px;
  margin: 20px 0;
  
  @media (max-width: 768px) {
    padding: 12px;
    margin: 15px 0;
    font-size: 13px;
  }
`;

const Credits = styled.div`
  display: flex;
  justify-content: space-between;
  background-color: #f2f8ff;
  border-radius: 5px;
  padding: 10px 15px;
  margin-bottom: 20px;
  align-items: center;
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    padding: 12px;
    
    div {
      margin-bottom: 10px;
      width: 100%;
    }
    
    button {
      width: 100%;
    }
  }
`;

const Input = styled.input`
  padding: 8px 12px;
  border-radius: 4px;
  border: 1px solid #ccc;
  width: 100%;
  margin-bottom: 15px;
  
  @media (max-width: 768px) {
    padding: 12px;
    font-size: 16px; /* Увеличиваем размер шрифта для лучшего ввода на мобильных */
  }
`;

const Tabs = styled.div`
  display: flex;
  margin-bottom: 20px;
  border-bottom: 1px solid #e0e0e0;
  
  @media (max-width: 768px) {
    margin-bottom: 15px;
  }
`;

const Tab = styled.div`
  padding: 10px 20px;
  cursor: pointer;
  border-bottom: 2px solid ${props => props.active ? '#4a6ee0' : 'transparent'};
  color: ${props => props.active ? '#4a6ee0' : '#666'};
  font-weight: ${props => props.active ? 'bold' : 'normal'};

  &:hover {
    color: #4a6ee0;
  }
  
  @media (max-width: 768px) {
    flex: 1;
    text-align: center;
    padding: 10px 5px;
    font-size: 14px;
  }
`;

const SelectContainer = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  
  label {
    margin-right: 10px;
  }
  
  select {
    padding: 8px;
    border-radius: 4px;
    border: 1px solid #ccc;
  }
  
  @media (max-width: 768px) {
    flex-direction: column;
    align-items: flex-start;
    
    label {
      margin-bottom: 8px;
      margin-right: 0;
    }
    
    select {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      margin-bottom: 10px;
    }
  }
`;

const RentalActionSection = styled.div`
  margin-top: 20px;
  
  @media (max-width: 768px) {
    margin-top: 15px;
  }
  
  h4 {
    margin-bottom: 10px;
  }
  
  div {
    @media (max-width: 768px) {
      flex-direction: column;
      
      select {
        width: 100%;
        margin-bottom: 10px;
      }
      
      button {
        width: 100%;
      }
    }
  }
`;

const PremiumIds = () => {
  const { user, updateUserData } = useContext(AuthContext);
  const [availableIds, setAvailableIds] = useState([]);
  const [userCredits, setUserCredits] = useState(0);
  const [selectedMonths, setSelectedMonths] = useState(1);
  const [loading, setLoading] = useState(false);
  const [customText, setCustomText] = useState('');
  const [activeTab, setActiveTab] = useState('browse');
  const [message, setMessage] = useState('');
  const [userPremiumId, setUserPremiumId] = useState(null);

  // Получение списка доступных ID
  useEffect(() => {
    if (user) {
      // Получаем список доступных ID
      axios.get('http://localhost:5000/api/premium-ids/available')
        .then(response => {
          setAvailableIds(response.data);
        })
        .catch(error => {
          console.error('Ошибка получения списка ID:', error);
        });

      // Получаем баланс кредитов пользователя
      axios.get('http://localhost:5000/api/credits/balance', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
        .then(response => {
          setUserCredits(response.data.credits);
        })
        .catch(error => {
          console.error('Ошибка получения баланса кредитов:', error);
        });

      // Проверяем, есть ли у пользователя премиальный ID
      if (user.premiumId) {
        setUserPremiumId({
          idValue: user.premiumId,
          expiresAt: user.premiumIdExpiresAt
        });
      }
    }
  }, [user]);

  // Аренда премиального ID
  const rentId = (idValue) => {
    setLoading(true);
    
    axios.post('http://localhost:5000/api/premium-ids/rent', {
      idValue,
      months: selectedMonths
    }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
      .then(response => {
        // Обновляем данные пользователя
        updateUserData(response.data.user);
        
        // Обновляем список доступных ID
        const updatedIds = availableIds.filter(id => id.idValue !== idValue);
        setAvailableIds(updatedIds);
        
        // Обновляем баланс кредитов
        setUserCredits(response.data.user.credits);
        
        // Обновляем информацию о премиальном ID пользователя
        setUserPremiumId({
          idValue: response.data.user.premiumId,
          expiresAt: response.data.user.premiumIdExpiresAt
        });
        
        // Показываем сообщение об успешной аренде
        setMessage(response.data.message);
        
        // Переключаемся на вкладку "Мой ID"
        setActiveTab('my-id');
      })
      .catch(error => {
        if (error.response && error.response.data) {
          setMessage(error.response.data.message);
        } else {
          setMessage('Произошла ошибка при аренде ID');
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  // Установка произвольного текста для ID
  const setCustomIdText = () => {
    if (!customText || customText.trim() === '') {
      setMessage('Введите текст для ID');
      return;
    }
    
    setLoading(true);
    
    axios.post('http://localhost:5000/api/premium-ids/customize', {
      customText: customText.trim()
    }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
      .then(response => {
        // Обновляем данные пользователя
        updateUserData(response.data.user);
        
        // Обновляем информацию о премиальном ID пользователя
        setUserPremiumId({
          idValue: response.data.user.premiumId,
          expiresAt: response.data.user.premiumIdExpiresAt
        });
        
        // Показываем сообщение об успешной установке текста
        setMessage(response.data.message);
        
        // Очищаем поле ввода
        setCustomText('');
      })
      .catch(error => {
        if (error.response && error.response.data) {
          setMessage(error.response.data.message);
        } else {
          setMessage('Произошла ошибка при установке текста ID');
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  // Продление аренды ID
  const extendRental = () => {
    if (!userPremiumId) {
      setMessage('У вас нет активного премиального ID');
      return;
    }
    
    setLoading(true);
    
    axios.post('http://localhost:5000/api/premium-ids/extend', {
      idValue: userPremiumId.idValue,
      months: selectedMonths
    }, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
      .then(response => {
        // Обновляем данные пользователя
        updateUserData(response.data.user);
        
        // Обновляем баланс кредитов
        setUserCredits(response.data.user.credits);
        
        // Обновляем информацию о премиальном ID пользователя
        setUserPremiumId({
          idValue: response.data.user.premiumId,
          expiresAt: response.data.user.premiumIdExpiresAt
        });
        
        // Показываем сообщение об успешном продлении
        setMessage(response.data.message);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          setMessage(error.response.data.message);
        } else {
          setMessage('Произошла ошибка при продлении аренды');
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  // Форматирование даты истечения
  const formatExpiryDate = (dateStr) => {
    if (!dateStr) return 'Не определено';
    
    const date = new Date(dateStr);
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Container>
      <Title>Премиальные ID</Title>
      
      <Credits>
        <div>
          <strong>Ваш баланс:</strong> {userCredits} кредитов
        </div>
        <Button onClick={() => window.location.href = '/credits'}>
          Пополнить
        </Button>
      </Credits>
      
      {message && (
        <InfoBox>
          {message}
        </InfoBox>
      )}
      
      <Tabs>
        <Tab 
          active={activeTab === 'browse'} 
          onClick={() => setActiveTab('browse')}
        >
          Доступные ID
        </Tab>
        <Tab 
          active={activeTab === 'my-id'} 
          onClick={() => setActiveTab('my-id')}
        >
          Мой ID
        </Tab>
      </Tabs>
      
      {activeTab === 'browse' && (
        <>
          <SelectContainer>
            <label>Количество месяцев аренды:</label>
            <select 
              value={selectedMonths} 
              onChange={e => setSelectedMonths(Number(e.target.value))}
            >
              <option value={1}>1 месяц</option>
              <option value={3}>3 месяца</option>
              <option value={6}>6 месяцев</option>
              <option value={12}>12 месяцев</option>
            </select>
          </SelectContainer>
          
          <IdList>
            {availableIds.map(id => (
              <IdCard 
                key={id._id} 
                highlight={id.idValue.startsWith('vip_') || id.idValue.startsWith('custom_text')}
              >
                <IdName>{id.idValue}</IdName>
                <IdPrice>{id.price} кредитов/месяц</IdPrice>
                <p>Всего: {id.price * selectedMonths} кредитов за {selectedMonths} мес.</p>
                <Button 
                  onClick={() => rentId(id.idValue)} 
                  disabled={loading || userCredits < id.price * selectedMonths}
                >
                  {loading ? 'Загрузка...' : 'Арендовать'}
                </Button>
              </IdCard>
            ))}
          </IdList>
          
          <InfoBox>
            <p>
              Премиальный ID даёт возможность использовать уникальный идентификатор в системе.
              Вы можете выбрать готовый ID или арендовать ID с возможностью установки произвольного текста.
            </p>
            <p>
              После аренды вы сможете продлить срок действия ID или изменить его текст (если это допускается типом ID).
            </p>
          </InfoBox>
        </>
      )}
      
      {activeTab === 'my-id' && (
        <>
          {userPremiumId ? (
            <div>
              <h3>Ваш текущий ID: {userPremiumId.idValue}</h3>
              <p>Срок действия до: {formatExpiryDate(userPremiumId.expiresAt)}</p>
              
              <RentalActionSection>
                <h4>Продление срока аренды</h4>
                <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
                  <select 
                    value={selectedMonths} 
                    onChange={e => setSelectedMonths(Number(e.target.value))}
                    style={{ padding: '8px' }}
                  >
                    <option value={1}>1 месяц</option>
                    <option value={3}>3 месяца</option>
                    <option value={6}>6 месяцев</option>
                    <option value={12}>12 месяцев</option>
                  </select>
                  <Button 
                    onClick={extendRental} 
                    disabled={loading}
                  >
                    {loading ? 'Загрузка...' : 'Продлить'}
                  </Button>
                </div>
              </RentalActionSection>
              
              {userPremiumId.idValue.startsWith('custom_text') && (
                <RentalActionSection>
                  <h4>Изменение текста ID</h4>
                  <Input 
                    type="text" 
                    placeholder="Введите новый текст для ID" 
                    value={customText} 
                    onChange={e => setCustomText(e.target.value)}
                  />
                  <Button 
                    onClick={setCustomIdText} 
                    disabled={loading || !customText.trim()}
                  >
                    {loading ? 'Загрузка...' : 'Изменить текст'}
                  </Button>
                </RentalActionSection>
              )}
            </div>
          ) : (
            <InfoBox>
              У вас пока нет активного премиального ID. Перейдите на вкладку "Доступные ID", чтобы арендовать.
            </InfoBox>
          )}
        </>
      )}
    </Container>
  );
};

export default PremiumIds; 