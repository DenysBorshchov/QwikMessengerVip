const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const dotenv = require('dotenv');
const mongoose = require('mongoose');

// Импорт маршрутов
const authRoutes = require('./routes/authRoutes');
const messageRoutes = require('./routes/messageRoutes');

// Загрузка переменных окружения
dotenv.config();

// Подключение к MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB подключена'))
  .catch(err => console.error('Ошибка подключения к MongoDB:', err));

// Инициализация приложения
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// Маршруты
app.use('/api/auth', authRoutes);
app.use('/api/messages', messageRoutes);

// Простой маршрут для проверки работы сервера
app.get('/', (req, res) => {
  res.send('Сервер мессенджера работает!');
});

// Отслеживание подключенных пользователей
const onlineUsers = new Map();

// Обработка соединений Socket.io
io.on('connection', (socket) => {
  console.log('Пользователь подключился:', socket.id);
  
  // Пользователь входит в систему
  socket.on('user_connected', (userId) => {
    onlineUsers.set(userId, socket.id);
    // Уведомляем всех о статусе пользователя
    io.emit('user_status', { userId, status: 'online' });
  });
  
  // Обработка отправки сообщения
  socket.on('send_message', (data) => {
    const receiverSocketId = onlineUsers.get(data.receiverId);
    
    if (receiverSocketId) {
      // Отправляем сообщение получателю
      io.to(receiverSocketId).emit('receive_message', data);
    }
  });
  
  // Обработка отключения
  socket.on('disconnect', () => {
    console.log('Пользователь отключился:', socket.id);
    
    // Находим отключившегося пользователя
    let disconnectedUserId = null;
    
    for (const [userId, socketId] of onlineUsers.entries()) {
      if (socketId === socket.id) {
        disconnectedUserId = userId;
        break;
      }
    }
    
    if (disconnectedUserId) {
      // Удаляем пользователя из онлайн-списка
      onlineUsers.delete(disconnectedUserId);
      // Уведомляем всех об изменении статуса
      io.emit('user_status', { userId: disconnectedUserId, status: 'offline' });
    }
  });
});

// Порт сервера
const PORT = process.env.PORT || 5000;

// Запуск сервера
server.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
}); 