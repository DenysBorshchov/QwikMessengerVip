import axios from 'axios';

const API_URL = 'http://localhost:5000/api/messages';

// Получение сообщений с конкретным пользователем
export const getMessages = async (recipientId) => {
  try {
    const response = await axios.get(`${API_URL}/${recipientId}`);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при получении сообщений';
  }
};

// Отправка сообщения
export const sendMessage = async (receiverId, content, attachments = []) => {
  try {
    const response = await axios.post(`${API_URL}/send`, {
      receiverId,
      content,
      attachments
    });
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при отправке сообщения';
  }
};

// Удаление сообщения
export const deleteMessage = async (messageId) => {
  try {
    const response = await axios.delete(`${API_URL}/${messageId}`);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при удалении сообщения';
  }
}; 