const express = require('express');
const router = express.Router();
const { 
  getMessages, 
  sendMessage, 
  getConversations 
} = require('../controllers/messageController');

// Получение сообщений между пользователями
router.get('/:userId/:receiverId', getMessages);

// Отправка сообщения
router.post('/', sendMessage);

// Получение списка переписок пользователя
router.get('/conversations/:userId', getConversations);

module.exports = router; 