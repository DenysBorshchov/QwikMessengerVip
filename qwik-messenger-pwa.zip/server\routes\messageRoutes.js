const express = require('express');
const router = express.Router();
const { sendMessage, getMessages, deleteMessage } = require('../controllers/messageController');
const { protect } = require('../middleware/authMiddleware');

// Все маршруты требуют аутентификации
router.use(protect);

// Маршрут для отправки сообщения
router.post('/send', sendMessage);

// Маршрут для получения сообщений между двумя пользователями
router.get('/:recipientId', getMessages);

// Маршрут для удаления сообщения
router.delete('/:messageId', deleteMessage);

module.exports = router; 