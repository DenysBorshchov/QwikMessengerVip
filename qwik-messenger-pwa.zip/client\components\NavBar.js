import React, { useContext, useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { AuthContext } from '../contexts/AuthContext';

const NavBarContainer = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #4a6ee0;
  padding: 0 20px;
  color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
  
  @media (max-width: 768px) {
    padding: 0 15px;
  }
`;

const Logo = styled.div`
  font-size: 24px;
  font-weight: bold;
  padding: 15px 0;
  
  a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
  }
  
  svg {
    margin-right: 10px;
  }
  
  @media (max-width: 768px) {
    font-size: 20px;
    
    span {
      display: none;
    }
    
    svg {
      margin-right: 0;
    }
  }
`;

const LogoText = styled.span`
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 100%;
    height: 3px;
    background-color: white;
    transform: scaleX(0);
    transition: transform 0.3s;
  }
  
  &:hover::after {
    transform: scaleX(1);
  }
`;

const MenuItems = styled.div`
  display: flex;
  
  @media (max-width: 768px) {
    display: ${props => props.isOpen ? 'flex' : 'none'};
    flex-direction: column;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background-color: #4a6ee0;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    padding: 10px 0;
    z-index: 100;
  }
`;

const MenuItem = styled(Link)`
  color: white;
  text-decoration: none;
  padding: 20px 15px;
  position: relative;
  font-weight: ${props => props.active ? 'bold' : 'normal'};
  
  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background-color: white;
    transform: scaleX(${props => props.active ? '1' : '0'});
    transition: transform 0.3s;
  }
  
  &:hover::after {
    transform: scaleX(1);
  }
  
  @media (max-width: 768px) {
    padding: 15px 20px;
    width: 100%;
    box-sizing: border-box;
    text-align: center;
    
    &::after {
      bottom: auto;
      top: 0;
      height: 0;
    }
    
    ${props => props.active && `
      background-color: #3757b6;
    `}
  }
`;

const UserSection = styled.div`
  display: flex;
  align-items: center;
  
  @media (max-width: 768px) {
    flex: 1;
    justify-content: flex-end;
  }
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  margin-right: 15px;
  
  span {
    margin-left: 10px;
  }
  
  @media (max-width: 768px) {
    margin-right: 10px;
    
    span {
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
`;

const CreditsDisplay = styled.div`
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 15px;
  padding: 5px 10px;
  margin-right: 15px;
  font-weight: bold;
  display: flex;
  align-items: center;
  
  svg {
    margin-right: 5px;
  }
  
  @media (max-width: 768px) {
    margin-right: 10px;
    padding: 5px 8px;
    font-size: 12px;
  }
`;

const Button = styled.button`
  background-color: transparent;
  border: 2px solid white;
  color: white;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: white;
    color: #4a6ee0;
  }
  
  @media (max-width: 768px) {
    padding: 6px 10px;
    font-size: 12px;
  }
`;

const BurgerMenu = styled.div`
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 30px;
  height: 21px;
  cursor: pointer;
  
  div {
    width: 100%;
    height: 3px;
    background-color: white;
    border-radius: 10px;
    transition: all 0.3s;
  }
  
  ${props => props.isOpen && `
    div:nth-child(1) {
      transform: translateY(9px) rotate(45deg);
    }
    
    div:nth-child(2) {
      opacity: 0;
    }
    
    div:nth-child(3) {
      transform: translateY(-9px) rotate(-45deg);
    }
  `}
  
  @media (max-width: 768px) {
    display: flex;
  }
`;

// Компонент иконки чата
const ChatIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM16 13H13V16C13 16.55 12.55 17 12 17C11.45 17 11 16.55 11 16V13H8C7.45 13 7 12.55 7 12C7 11.45 7.45 11 8 11H11V8C11 7.45 11.45 7 12 7C12.55 7 13 7.45 13 8V11H16C16.55 11 17 11.45 17 12C17 12.55 16.55 13 16 13Z" fill="white"/>
  </svg>
);

// Компонент иконки монеты для кредитов
const CoinIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20ZM11 7H13V9H11V7ZM11 11H13V17H11V11Z" fill="white"/>
  </svg>
);

const NavBar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  
  // Закрываем меню при изменении маршрута
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);
  
  // Закрываем меню при клике вне его
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuOpen && !event.target.closest('nav')) {
        setMenuOpen(false);
      }
    };
    
    document.addEventListener('click', handleClickOutside);
    
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [menuOpen]);
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Ошибка при выходе из системы:', error);
    }
  };
  
  return (
    <NavBarContainer>
      <Logo>
        <Link to="/">
          <ChatIcon />
          <LogoText>Qwik Мессенджер</LogoText>
        </Link>
      </Logo>
      
      {user && (
        <>
          <BurgerMenu isOpen={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
            <div></div>
            <div></div>
            <div></div>
          </BurgerMenu>
          
          <MenuItems isOpen={menuOpen}>
            <MenuItem to="/" active={location.pathname === '/' ? 'true' : undefined}>
              Чат
            </MenuItem>
            <MenuItem to="/premium-ids" active={location.pathname === '/premium-ids' ? 'true' : undefined}>
              Премиум ID
            </MenuItem>
            <MenuItem to="/credits" active={location.pathname === '/credits' ? 'true' : undefined}>
              Кредиты
            </MenuItem>
          </MenuItems>
          
          <UserSection>
            {user.credits !== undefined && (
              <CreditsDisplay>
                <CoinIcon />
                {user.credits}
              </CreditsDisplay>
            )}
            
            <UserInfo>
              <span>
                {user.premiumId ? (
                  <strong style={{ color: '#ffde59' }}>
                    {user.premiumId}
                  </strong>
                ) : (
                  user.username
                )}
              </span>
            </UserInfo>
            
            <Button onClick={handleLogout}>Выйти</Button>
          </UserSection>
        </>
      )}
    </NavBarContainer>
  );
};

export default NavBar; 