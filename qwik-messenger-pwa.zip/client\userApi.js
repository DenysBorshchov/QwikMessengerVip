import axios from 'axios';

const API_URL = 'http://localhost:5000/api/users';

// Получение списка всех пользователей
export const getAllUsers = async () => {
  try {
    const response = await axios.get(`${API_URL}`);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при получении пользователей';
  }
};

// Поиск пользователей по имени
export const searchUsers = async (query) => {
  try {
    const response = await axios.get(`${API_URL}/search?query=${query}`);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при поиске пользователей';
  }
};

// Получение профиля пользователя
export const getUserProfile = async (userId) => {
  try {
    const response = await axios.get(`${API_URL}/${userId}`);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при получении профиля пользователя';
  }
};

// Обновление профиля пользователя
export const updateUserProfile = async (userData) => {
  try {
    const response = await axios.put(`${API_URL}/profile`, userData);
    return response.data;
  } catch (error) {
    throw error.response?.data?.message || 'Ошибка при обновлении профиля';
  }
}; 