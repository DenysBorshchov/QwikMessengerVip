import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { AuthProvider } from './contexts/AuthContext';
import { BrowserRouter } from 'react-router-dom';

// Рендеринг приложения
ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);

// Регистрация Service Worker (PWA)
window.addEventListener('load', () => {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('Service Worker зарегистрирован успешно:', registration.scope);
      })
      .catch(error => {
        console.error('Ошибка при регистрации Service Worker:', error);
      });
  }
});

// Обработка установки PWA
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  // Предотвращаем появление стандартного диалога установки
  e.preventDefault();
  // Сохраняем событие для последующего использования
  deferredPrompt = e;
  
  // Здесь можно показать свою кнопку установки
  // или другую подсказку для пользователя
  const installButton = document.getElementById('install-button');
  if (installButton) {
    installButton.style.display = 'block';
    installButton.addEventListener('click', installApp);
  }
});

// Функция для установки приложения
function installApp() {
  if (!deferredPrompt) {
    return;
  }
  
  // Показываем диалог установки
  deferredPrompt.prompt();
  
  // Ждем, пока пользователь примет решение
  deferredPrompt.userChoice.then((choiceResult) => {
    if (choiceResult.outcome === 'accepted') {
      console.log('Пользователь установил приложение');
    } else {
      console.log('Пользователь отклонил установку');
    }
    
    // Сбрасываем сохраненное событие
    deferredPrompt = null;
    
    // Скрываем кнопку установки
    const installButton = document.getElementById('install-button');
    if (installButton) {
      installButton.style.display = 'none';
    }
  });
} 