const express = require('express');
const router = express.Router();
const { register, login, getProfile } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');

// Маршрут для регистрации
router.post('/register', register);

// Маршрут для входа
router.post('/login', login);

// Маршрут для получения профиля (требует аутентификации)
router.get('/profile', protect, getProfile);

module.exports = router; 