import React, { useState, useEffect, useRef, useContext } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import styled from 'styled-components';
import { AuthContext } from '../contexts/AuthContext';

// Основной контейнер
const ChatContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: calc(100vh - 120px);
  max-height: calc(100vh - 120px);
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  
  @media (max-width: 768px) {
    height: calc(100vh - 100px);
    max-height: calc(100vh - 100px);
    border-radius: 8px;
  }
`;

// Список контактов
const ContactsList = styled.div`
  width: 100%;
  display: ${props => props.showContacts ? 'flex' : 'none'};
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  border-right: 1px solid #eee;
  
  @media (max-width: 768px) {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 10;
    background-color: #fff;
    border-right: none;
  }
`;

// Заголовок контактов
const ContactsHeader = styled.div`
  padding: 15px;
  border-bottom: 1px solid #eee;
  font-weight: bold;
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 768px) {
    padding: 12px;
  }
`;

// Элемент контакта
const ContactItem = styled.div`
  padding: 12px 15px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
  display: flex;
  align-items: center;
  background-color: ${props => props.active ? '#f0f7ff' : 'transparent'};
  
  &:hover {
    background-color: #f5f5f5;
  }
  
  @media (max-width: 768px) {
    padding: 15px;
  }
`;

// Аватар контакта
const ContactAvatar = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #4a6ee0;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin-right: 10px;
  
  @media (max-width: 768px) {
    width: 50px;
    height: 50px;
  }
`;

// Информация о контакте
const ContactInfo = styled.div`
  flex: 1;
`;

// Имя контакта
const ContactName = styled.div`
  font-weight: bold;
`;

// Последнее сообщение
const LastMessage = styled.div`
  color: #666;
  font-size: 12px;
  margin-top: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 150px;
  
  @media (max-width: 768px) {
    max-width: 250px;
  }
`;

// Область сообщений
const MessageArea = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100%;
  
  @media (max-width: 768px) {
    display: ${props => props.showContacts ? 'none' : 'flex'};
  }
`;

// Заголовок чата
const ChatHeader = styled.div`
  padding: 15px;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: space-between;
  
  @media (max-width: 768px) {
    padding: 12px;
  }
`;

// Кнопка назад для мобильной версии
const BackButton = styled.div`
  display: none;
  margin-right: 10px;
  width: 30px;
  height: 30px;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  
  svg {
    width: 20px;
    height: 20px;
  }
  
  @media (max-width: 768px) {
    display: flex;
  }
`;

// Информация о текущем контакте
const CurrentContactInfo = styled.div`
  display: flex;
  align-items: center;
  flex: 1;
`;

// Контейнер для сообщений
const MessagesContainer = styled.div`
  flex: 1;
  padding: 15px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  
  @media (max-width: 768px) {
    padding: 10px;
  }
`;

// Отдельное сообщение
const Message = styled.div`
  max-width: 70%;
  padding: 10px 15px;
  border-radius: 18px;
  margin-bottom: 10px;
  align-self: ${props => props.sent ? 'flex-end' : 'flex-start'};
  background-color: ${props => props.sent ? '#4a6ee0' : '#f0f0f0'};
  color: ${props => props.sent ? 'white' : 'black'};
  position: relative;
  word-wrap: break-word;
  
  @media (max-width: 768px) {
    max-width: 80%;
    padding: 8px 12px;
  }
`;

// Время сообщения
const MessageTime = styled.div`
  font-size: 10px;
  color: ${props => props.sent ? 'rgba(255, 255, 255, 0.7)' : '#999'};
  text-align: right;
  margin-top: 4px;
`;

// Форма ввода сообщения
const MessageInputForm = styled.form`
  display: flex;
  padding: 10px;
  border-top: 1px solid #eee;
  align-items: center;
  
  @media (max-width: 768px) {
    padding: 8px;
  }
`;

// Поле ввода сообщения
const MessageInput = styled.input`
  flex: 1;
  padding: 10px 15px;
  border: 1px solid #ddd;
  border-radius: 20px;
  outline: none;
  
  &:focus {
    border-color: #4a6ee0;
  }
  
  @media (max-width: 768px) {
    padding: 12px;
    font-size: 16px;
  }
`;

// Кнопка отправки сообщения
const SendButton = styled.button`
  background-color: #4a6ee0;
  color: white;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-left: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  
  &:disabled {
    background-color: #ccc;
  }
  
  @media (max-width: 768px) {
    width: 45px;
    height: 45px;
  }
`;

// Иконка отправки
const SendIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2.01 21L23 12L2.01 3L2 10L17 12L2 14L2.01 21Z" fill="white" />
  </svg>
);

// Иконка назад
const BackIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 11H7.83L13.42 5.41L12 4L4 12L12 20L13.41 18.59L7.83 13H20V11Z" fill="#4a6ee0" />
  </svg>
);

// Основной компонент чата
const MobileChat = () => {
  const { user } = useContext(AuthContext);
  const [contacts, setContacts] = useState([]);
  const [currentContact, setCurrentContact] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [socket, setSocket] = useState(null);
  const [showContacts, setShowContacts] = useState(true);
  const messagesEndRef = useRef(null);

  // Подключение к серверу Socket.IO
  useEffect(() => {
    const newSocket = io('http://localhost:5000');
    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  // Подключение к комнате пользователя при аутентификации
  useEffect(() => {
    if (socket && user) {
      socket.emit('join', user._id);

      // Обработка входящих сообщений
      socket.on('newMessage', message => {
        if (currentContact && 
            ((message.sender === currentContact._id && message.receiver === user._id) ||
             (message.sender === user._id && message.receiver === currentContact._id))) {
          setMessages(prev => [...prev, message]);
        } else {
          // Обновление последнего сообщения в списке контактов
          setContacts(prev => {
            return prev.map(contact => {
              if (contact._id === message.sender) {
                return { ...contact, lastMessage: message.content };
              }
              return contact;
            });
          });
        }
      });
    }

    return () => {
      if (socket) {
        socket.off('newMessage');
      }
    };
  }, [socket, user, currentContact]);

  // Получение контактов
  useEffect(() => {
    if (user) {
      axios.get('http://localhost:5000/api/users', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
        .then(response => {
          // Фильтруем текущего пользователя из списка контактов
          const filteredContacts = response.data.filter(contact => contact._id !== user._id);
          setContacts(filteredContacts);
        })
        .catch(error => {
          console.error('Ошибка получения контактов:', error);
        });
    }
  }, [user]);

  // Получение сообщений при выборе контакта
  useEffect(() => {
    if (currentContact && user) {
      setShowContacts(false);
      
      axios.get(`http://localhost:5000/api/messages/${currentContact._id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
        .then(response => {
          setMessages(response.data);
        })
        .catch(error => {
          console.error('Ошибка получения сообщений:', error);
        });
    }
  }, [currentContact, user]);

  // Прокрутка к последнему сообщению
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Выбор контакта
  const selectContact = (contact) => {
    setCurrentContact(contact);
  };

  // Отправка сообщения
  const sendMessage = (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !currentContact) return;

    const messageData = {
      sender: user._id,
      receiver: currentContact._id,
      content: newMessage.trim(),
      timestamp: new Date()
    };

    axios.post('http://localhost:5000/api/messages', messageData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    })
      .then(response => {
        // Сообщение успешно отправлено
        socket.emit('sendMessage', response.data);
        setMessages(prev => [...prev, response.data]);
        setNewMessage('');
        
        // Обновление последнего сообщения в списке контактов
        setContacts(prev => {
          return prev.map(contact => {
            if (contact._id === currentContact._id) {
              return { ...contact, lastMessage: newMessage.trim() };
            }
            return contact;
          });
        });
      })
      .catch(error => {
        console.error('Ошибка отправки сообщения:', error);
        
        // Сохраняем сообщение локально для синхронизации в будущем (для офлайн режима)
        if ('indexedDB' in window) {
          saveMessageToIndexedDB(messageData);
        }
      });
  };

  // Сохранение сообщения в IndexedDB для отправки позже (офлайн режим)
  const saveMessageToIndexedDB = (message) => {
    const request = indexedDB.open('qwikMessenger', 1);
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('unsentMessages')) {
        db.createObjectStore('unsentMessages', { keyPath: 'id', autoIncrement: true });
      }
    };
    
    request.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction(['unsentMessages'], 'readwrite');
      const store = transaction.objectStore('unsentMessages');
      
      store.add({
        data: message,
        token: localStorage.getItem('token')
      });
      
      // Запрашиваем синхронизацию, когда появится сеть
      if ('serviceWorker' in navigator && 'SyncManager' in window) {
        navigator.serviceWorker.ready.then(registration => {
          registration.sync.register('syncMessages');
        });
      }
    };
  };

  // Форматирование времени сообщения
  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Возврат к списку контактов (мобильная версия)
  const goBackToContacts = () => {
    setShowContacts(true);
  };

  return (
    <ChatContainer>
      <ContactsList showContacts={showContacts}>
        <ContactsHeader>
          Чаты
        </ContactsHeader>
        {contacts.map(contact => (
          <ContactItem 
            key={contact._id} 
            onClick={() => selectContact(contact)}
            active={currentContact && currentContact._id === contact._id}
          >
            <ContactAvatar>
              {contact.username ? contact.username.charAt(0).toUpperCase() : 'U'}
            </ContactAvatar>
            <ContactInfo>
              <ContactName>{contact.premiumId || contact.username}</ContactName>
              {contact.lastMessage && (
                <LastMessage>{contact.lastMessage}</LastMessage>
              )}
            </ContactInfo>
          </ContactItem>
        ))}
      </ContactsList>
      
      <MessageArea showContacts={showContacts}>
        {currentContact ? (
          <>
            <ChatHeader>
              <CurrentContactInfo>
                <BackButton onClick={goBackToContacts}>
                  <BackIcon />
                </BackButton>
                <ContactAvatar>
                  {currentContact.username ? currentContact.username.charAt(0).toUpperCase() : 'U'}
                </ContactAvatar>
                <ContactName>{currentContact.premiumId || currentContact.username}</ContactName>
              </CurrentContactInfo>
            </ChatHeader>
            
            <MessagesContainer>
              {messages.map((message, index) => (
                <Message 
                  key={message._id || index} 
                  sent={message.sender === user._id}
                >
                  {message.content}
                  <MessageTime sent={message.sender === user._id}>
                    {formatMessageTime(message.timestamp)}
                  </MessageTime>
                </Message>
              ))}
              <div ref={messagesEndRef} />
            </MessagesContainer>
            
            <MessageInputForm onSubmit={sendMessage}>
              <MessageInput 
                type="text" 
                placeholder="Введите сообщение..." 
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <SendButton type="submit" disabled={!newMessage.trim()}>
                <SendIcon />
              </SendButton>
            </MessageInputForm>
          </>
        ) : (
          <div style={{ padding: '20px', textAlign: 'center' }}>
            Выберите контакт для начала общения
          </div>
        )}
      </MessageArea>
    </ChatContainer>
  );
};

export default MobileChat; 