const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Middleware для проверки аутентификации
const protect = async (req, res, next) => {
  let token;
  
  // Проверяем наличие токена в заголовках
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      // Получаем токен из заголовка
      token = req.headers.authorization.split(' ')[1];
      
      // Верифицируем токен
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Находим пользователя по ID из токена
      req.user = await User.findById(decoded.id).select('-password');
      
      next();
    } catch (error) {
      console.error('Ошибка при аутентификации:', error);
      res.status(401).json({ message: 'Не авторизован, токен недействителен' });
    }
  }
  
  if (!token) {
    res.status(401).json({ message: 'Не авторизован, токен не предоставлен' });
  }
};

module.exports = { protect }; 